(() => {
    "use strict";
    window.PQNAS_PHOTOGALLERY = window.PQNAS_PHOTOGALLERY || {};
    const el = (id) => document.getElementById(id);

    function pgT(key, params, fallback) {
        try {
            const api = window.PQNAS_I18N;
            if (api && typeof api.t === "function") {
                return api.t(key, params || null, fallback);
            }
        } catch (_) {}

        let out = String(fallback || key || "");
        const p = params || {};
        for (const name of Object.keys(p)) {
            out = out.split(`{${name}}`).join(String(p[name]));
        }
        return out;
    }

    try {
        if (window.self !== window.top) document.body.classList.add("embedded");
    } catch (_) {
        document.body.classList.add("embedded");
    }

    const titleLine = el("titleLine");
    const pathLine = el("pathLine");
    const badge = el("badge");
    const statusEl = el("status");
    const footerStats = el("footerStats");
    const filterInput = el("filterInput");
    const ratingFilter = el("ratingFilter");
    const thumbSizeSelect = el("thumbSizeSelect");
    const refreshBtn = el("refreshBtn");
    const upBtn = el("upBtn");
    const gridEl = el("grid");
    const ctxMenu = el("ctxMenu");

    const gridWrap = el("gridWrap");

    const downloadSelBtn = el("downloadSelBtn");
    const deleteSelBtn = el("deleteSelBtn");
    const clearSelBtn = el("clearSelBtn");
    const selCount = el("selCount");

    const metaModal = el("metaModal");
    const metaClose = el("metaClose");
    const metaPath = el("metaPath");
    const metaStars = el("metaStars");
    const metaTags = el("metaTags");
    const metaNotes = el("metaNotes");
    const metaInfo = el("metaInfo");
    const metaStatus = el("metaStatus");
    const metaSaveBtn = el("metaSaveBtn");
    const metaApplySelWrap = el("metaApplySelWrap");
    const metaApplySelChk = el("metaApplySelChk");
    const metaApplySelText = el("metaApplySelText");

    const previewModal = el("previewModal");
    const previewCard = el("previewCard");
    const previewHead = el("previewHead");
    const previewPath = el("previewPath");
    const previewInfo = el("previewInfo");
    const previewImg = el("previewImg");
    const previewBody = previewCard ? previewCard.querySelector(".previewBody") : null;

    const previewPrevBtn = el("previewPrevBtn");
    const previewNextBtn = el("previewNextBtn");
    const previewFitBtn = el("previewFitBtn");
    const previewActualBtn = el("previewActualBtn");
    const previewMetaBtn = el("previewMetaBtn");
    const previewClose = el("previewClose");
    const previewShareBtn = el("previewShareBtn");
    const previewFullscreenBtn = el("previewFullscreenBtn");

    function applyPreviewButtonTranslations() {
        if (!previewFullscreenBtn) return;

        const isFullscreen = document.fullscreenElement === previewCard;
        const key = isFullscreen ? "photogallery.exit_fullscreen" : "photogallery.fullscreen";
        const fallback = isFullscreen
            ? "Poistu koko näytöstä"
            : (previewFullscreenBtn.textContent || "Koko näyttö");

        previewFullscreenBtn.setAttribute("data-i18n", key);
        previewFullscreenBtn.textContent = pgT(key, null, fallback);
    }



    document.addEventListener("fullscreenchange", applyPreviewButtonTranslations);

    const metaCard = el("metaCard");
    const metaHead = el("metaHead");

    const gridBtn = el("gridBtn");
    const mapBtn = el("mapBtn");
    const albumsBtn = el("albumsBtn");
    const mapWrap = el("mapWrap");
    const mapCanvas = el("mapCanvas");
    const albumsWrap = el("albumsWrap");

    function applyTopbarTooltipTranslations() {
        const items = [
            ["slideshowBtn", "photogallery.start_slideshow", "Aloita diaesitys", "Aloita diaesitys"],
            ["statsBtn", "photogallery.stats_tooltip", "Näytä kuvatilastot", "Tilastot"],
            ["gridBtn", "photogallery.grid_tooltip", "Ruudukkonäkymä", "Ruudukko"],
            ["mapBtn", "photogallery.map_tooltip", "Karttanäkymä", "Kartta"],
            ["albumsBtn", "photogallery.albums_tooltip", "Albumit", "Albumit"],
            ["upBtn", "photogallery.up_tooltip", "Ylös kansiotasolla", "Ylös"],
            ["refreshBtn", "common.refresh", "Päivitä", "Päivitä"],
        ];

        for (const [id, key, fallbackTitle, fallbackText] of items) {
            const node = el(id);
            if (!node) continue;

            const title = pgT(key, null, fallbackTitle);
            node.setAttribute("title", title);
            node.setAttribute("aria-label", title);
            node.setAttribute("data-i18n-title", key);
            node.setAttribute("data-i18n-aria-label", key);

            if (["gridBtn", "mapBtn", "albumsBtn", "slideshowBtn"].includes(id)) {
                const textKey = id === "gridBtn"
                    ? "photogallery.grid"
                    : id === "mapBtn"
                        ? "photogallery.map"
                        : id === "albumsBtn"
                            ? "photogallery.albums"
                            : "photogallery.slideshow";
                node.textContent = pgT(textKey, null, fallbackText);
            }
        }
    }

    function scheduleTopbarTooltipTranslations() {
        applyTopbarTooltipTranslations();
        window.setTimeout(applyTopbarTooltipTranslations, 0);
        window.setTimeout(applyTopbarTooltipTranslations, 100);
    }

    scheduleTopbarTooltipTranslations();
    window.addEventListener("load", scheduleTopbarTooltipTranslations);

    for (const id of ["slideshowBtn", "statsBtn", "gridBtn", "mapBtn", "albumsBtn", "upBtn", "refreshBtn"]) {
        el(id)?.addEventListener("click", () => {
            window.setTimeout(applyTopbarTooltipTranslations, 0);
            window.setTimeout(applyTopbarTooltipTranslations, 80);
        });
    }

    function forceTopbarFinnishLabelsAndTitles() {
        const values = [
            ["slideshowBtn", "photogallery.slideshow", "Diaesitys", "photogallery.start_slideshow", "Aloita diaesitys"],
            ["gridBtn", "photogallery.grid", "Ruudukko", "photogallery.switch_to_grid_view", "Siirry ruudukkonäkymään"],
            ["mapBtn", "photogallery.map", "Kartta", "photogallery.switch_to_map_view", "Siirry karttanäkymään"],
            ["albumsBtn", "photogallery.albums", "Albumit", "photogallery.switch_to_albums_view", "Siirry albumeihin"],
            ["statsBtn", "photogallery.stats", "Tilastot", "photogallery.stats_tooltip", "Näytä kuvatilastot"],
        ];

        for (const [id, textKey, fallbackText, titleKey, fallbackTitle] of values) {
            const node = el(id);
            if (!node) continue;
            node.textContent = pgT(textKey, null, fallbackText);
            const title = pgT(titleKey, null, fallbackTitle);
            node.setAttribute("title", title);
            node.setAttribute("aria-label", title);
            node.setAttribute("data-i18n", textKey);
            node.setAttribute("data-i18n-title", titleKey);
            node.setAttribute("data-i18n-aria-label", titleKey);
        }
    }

    function scheduleTopbarFinnishLabelsAndTitles() {
        forceTopbarFinnishLabelsAndTitles();
        window.setTimeout(forceTopbarFinnishLabelsAndTitles, 0);
        window.setTimeout(forceTopbarFinnishLabelsAndTitles, 100);
        window.setTimeout(forceTopbarFinnishLabelsAndTitles, 500);
    }

    const panelEl = document.querySelector(".panel");

    let metaSaveInFlight = false;
    let suppressBrowserSaveUntil = 0;
    let selectedRelPaths = new Set();
    let selectionAnchorRelPath = "";
    let searchSeq = 0;
    let filterTimer = 0;
    const externalSearchFilters = [];

    scheduleTopbarFinnishLabelsAndTitles();
    window.addEventListener("load", scheduleTopbarFinnishLabelsAndTitles);
    for (const id of ["slideshowBtn", "gridBtn", "mapBtn", "albumsBtn", "statsBtn"]) {
        el(id)?.addEventListener("click", scheduleTopbarFinnishLabelsAndTitles);
    }

    const FOLDER_LIST_CACHE_TTL_MS = 30 * 1000;
    const ENABLE_AUTO_TREE_STATS = true;

    const folderListCache = new Map();

    let serverTreeStatsSupported = null;
    let serverRecursiveSearchSupported = null;

    function folderListCacheKey(relPath) {
        return normalizeRelPath(relPath || "");
    }

    function cloneGalleryItem(it) {
        if (!it || typeof it !== "object") return it;

        return {
            ...it,
            keywords: Array.isArray(it.keywords) ? it.keywords.slice() : it.keywords
        };
    }

    function cloneGalleryItems(items) {
        return Array.isArray(items) ? items.map(cloneGalleryItem) : [];
    }

    function clearFolderListCache() {
        folderListCache.clear();
    }

    function pqnasGalleryInternalTopName(item) {
        if (!item || typeof item !== "object") return "";

        const name = String(item.name || item.basename || "").trim();
        const rel = String(
            item.rel_path ||
            item.logical_rel_path ||
            item.path ||
            item.rel ||
            ""
        ).replace(/^\/+/, "");

        const first = rel ? String(rel.split("/")[0] || "").trim() : "";
        return first || name;
    }

    function isInternalPqnasGalleryEntry(item) {
        const top = pqnasGalleryInternalTopName(item);
        if (!top) return false;

        // Hide app/private metadata folders from user-facing gallery views.
        // Examples: .pqnas_activity, .pqnas_echostack, .pqnas_photogallery, etc.
        return top === ".pqnas" || top.startsWith(".pqnas_");
    }

    function filterInternalPqnasGalleryItems(items) {
        if (!Array.isArray(items)) return [];
        return items.filter((item) => !isInternalPqnasGalleryEntry(item));
    }

    async function fetchGalleryList(relPath, opts = {}) {
        const path = normalizeRelPath(relPath || "");
        const key = folderListCacheKey(path);
        const force = opts.force === true;
        const now = Date.now();

        if (!force) {
            const cached = folderListCache.get(key);
            if (cached && now - cached.ts < FOLDER_LIST_CACHE_TTL_MS) {
                return {
                    ...cached.response,
                    items: cloneGalleryItems(cached.items),
                    _cache: "memory"
                };
            }
        }

        const j = await fetchJson(galleryListUrl(path));

        const items = cloneGalleryItems(filterInternalPqnasGalleryItems(Array.isArray(j.items) ? j.items : []));

        folderListCache.set(key, {
            ts: now,
            response: {
                ...j,
                items: []
            },
            items
        });

        return {
            ...j,
            items: cloneGalleryItems(items),
            _cache: "network"
        };
    }

    const RATING_FILTER_KEY = "pqnas_photogallery_rating_filter_v1";

    const THUMB_SIZE_KEY = "pqnas_photogallery_thumb_size_v1";

    const state = {
        curPath: "",
        items: [],
        filter: "",
        ratingFilter: -1, // -1 = all, 0 = unrated, 1..5 = exact stars
        thumbSize: 160,
        viewMode: "grid",
        editingPath: "",
        editingRating: 0,
        previewPath: "",
        previewMode: "fit",
        previewZoom: 1,
        activeTilePath: "",
        mapFocusRelPath: "",
        searchItems: [],
        searchBasePath: "",
        searchLoaded: false,
        searchLoading: false,
        treeStats: {
            basePath: "",
            loaded: false,
            loading: false,
            dirs: 0,
            files: 0,
            fileBytes: 0,
            seq: 0
        }
    };


    function injectTopModeButtonCss() {
        if (document.getElementById("pgTopModeButtonCss")) return;

        const style = document.createElement("style");
        style.id = "pgTopModeButtonCss";
        style.textContent = `
.pgTopModeBtnActive{
    appearance: none !important;
    -webkit-appearance: none !important;
    border-color: rgba(75,145,190,0.88) !important;
    background: linear-gradient(180deg, #9fd3ec 0%, #6aaed6 48%, #4b92bd 100%) !important;
    background-image: linear-gradient(180deg, #9fd3ec 0%, #6aaed6 48%, #4b92bd 100%) !important;
    background-color: #6aaed6 !important;
    color: #03111b !important;
    font-weight: 950 !important;
    text-shadow: 0 1px 0 rgba(255,255,255,0.35) !important;
    box-shadow:
        inset 0 0 0 1px rgba(255,255,255,0.72),
        0 0 0 2px rgba(45,120,170,0.24),
        0 0 14px rgba(45,120,170,0.18) !important;
}

.pgTopModeBtnActive:hover{
    background: linear-gradient(180deg, #b8dff0 0%, #78bade 48%, #5599c4 100%) !important;
    background-image: linear-gradient(180deg, #b8dff0 0%, #78bade 48%, #5599c4 100%) !important;
    background-color: #78bade !important;
    color: #03111b !important;
}

.pgTopModeBtnActive:focus{
    outline: 2px solid rgba(45,120,170,0.35);
    outline-offset: 2px;
}

html[data-theme="bright"] .pgTopModeBtnActive,
html[data-theme="win_classic"] .pgTopModeBtnActive,
html[data-theme="dark"] .pgTopModeBtnActive,
html[data-theme="cpunk_orange"] .pgTopModeBtnActive,
html[data-theme="orange"] .pgTopModeBtnActive{
    border-color: rgba(75,145,190,0.88) !important;
    background: linear-gradient(180deg, #9fd3ec 0%, #6aaed6 48%, #4b92bd 100%) !important;
    background-image: linear-gradient(180deg, #9fd3ec 0%, #6aaed6 48%, #4b92bd 100%) !important;
    background-color: #6aaed6 !important;
    color: #03111b !important;
}
`;
        document.head.appendChild(style);
    }

    function setTopModeButtonActive(mode) {
        injectTopModeButtonCss();

        const activeBg = "linear-gradient(180deg, #9fd3ec 0%, #6aaed6 48%, #4b92bd 100%)";
        const activeBorder = "rgba(75,145,190,0.88)";
        const activeText = "#03111b";
        const activeShadow =
            "inset 0 0 0 1px rgba(255,255,255,0.72), " +
            "0 0 0 2px rgba(45,120,170,0.24), " +
            "0 0 14px rgba(45,120,170,0.18)";

        const entries = [
            ["grid", gridBtn],
            ["map", mapBtn],
            ["albums", albumsBtn],
        ];

        for (const [key, btn] of entries) {
            if (!btn) continue;

            const active = key === mode;
            btn.classList.toggle("pgTopModeBtnActive", active);
            btn.setAttribute("aria-pressed", active ? "true" : "false");
            btn.title = active ? `${btn.textContent.trim()} view is active` : `Switch to ${btn.textContent.trim()} view`;

            if (active) {
                btn.style.setProperty("appearance", "none", "important");
                btn.style.setProperty("-webkit-appearance", "none", "important");
                btn.style.setProperty("background", activeBg, "important");
                btn.style.setProperty("background-image", activeBg, "important");
                btn.style.setProperty("background-color", "#6aaed6", "important");
                btn.style.setProperty("border-color", activeBorder, "important");
                btn.style.setProperty("color", activeText, "important");
                btn.style.setProperty("box-shadow", activeShadow, "important");
                btn.style.setProperty("font-weight", "950", "important");
                btn.style.setProperty("text-shadow", "0 1px 0 rgba(255,255,255,0.35)", "important");
            } else {
                btn.style.removeProperty("appearance");
                btn.style.removeProperty("-webkit-appearance");
                btn.style.removeProperty("background");
                btn.style.removeProperty("background-image");
                btn.style.removeProperty("background-color");
                btn.style.removeProperty("border-color");
                btn.style.removeProperty("color");
                btn.style.removeProperty("box-shadow");
                btn.style.removeProperty("font-weight");
                btn.style.removeProperty("text-shadow");
            }
        }
    }

    function syncTopModeButtonActive() {
        let mode = String(state.viewMode || "grid");

        if (albumsWrap && albumsWrap.style.display !== "none") {
            mode = "albums";
        } else if (mapWrap && mapWrap.style.display !== "none") {
            mode = "map";
        } else {
            mode = "grid";
        }

        setTopModeButtonActive(mode);
    }

    function wireTopModeButtonActive() {
        injectTopModeButtonCss();

        if (gridBtn) {
            gridBtn.addEventListener("click", () => {
                window.setTimeout(() => setTopModeButtonActive("grid"), 0);
            });
        }

        if (mapBtn) {
            mapBtn.addEventListener("click", () => {
                window.setTimeout(() => setTopModeButtonActive("map"), 0);
            });
        }

        if (albumsBtn) {
            albumsBtn.addEventListener("click", () => {
                window.setTimeout(() => setTopModeButtonActive("albums"), 0);
            });
        }

        setTopModeButtonActive(state.viewMode || "grid");

        window.setTimeout(syncTopModeButtonActive, 0);
        window.setTimeout(syncTopModeButtonActive, 250);
    }

    const dragState = {
        active: false,
        startX: 0,
        startY: 0,
        cardLeft: 0,
        cardTop: 0,
        moved: false
    };

    const metaDragState = {
        active: false,
        startX: 0,
        startY: 0,
        cardLeft: 0,
        cardTop: 0
    };

    const previewPanState = {
        active: false,
        startX: 0,
        startY: 0,
        scrollLeft: 0,
        scrollTop: 0,
        moved: false
    };

    const mapRuntime = {
        leafletPromise: null,
        map: null,
        markersLayer: null,
        tileLayer: null
    };

    function loadRatingFilterPref() {
        try {
            const raw = Number(localStorage.getItem(RATING_FILTER_KEY) || "-1");
            if (raw >= -1 && raw <= 5) {
                state.ratingFilter = raw;
            }
        } catch (_) {
            state.ratingFilter = -1;
        }

        if (ratingFilter) {
            ratingFilter.value = String(state.ratingFilter);
        }
    }

    function saveRatingFilterPref() {
        try {
            localStorage.setItem(RATING_FILTER_KEY, String(state.ratingFilter));
        } catch (_) {}
    }
    function applyThumbSizeUi() {
        const size = Number(state.thumbSize || 160);

        if (gridEl) {
            gridEl.style.setProperty("--pg-tile-min", `${size}px`);
            gridEl.style.setProperty("--pg-thumb-height", `${Math.round(size * 0.82)}px`);
        }

        if (thumbSizeSelect) {
            thumbSizeSelect.value = String(size);
        }
    }


    function loadThumbSizePref() {
        try {
            const raw = Number(localStorage.getItem(THUMB_SIZE_KEY) || "160");
            if ([120, 160, 220, 300].includes(raw)) {
                state.thumbSize = raw;
            } else {
                state.thumbSize = 160;
            }
        } catch (_) {
            state.thumbSize = 160;
        }

        applyThumbSizeUi();
    }

    function saveThumbSizePref() {
        try {
            localStorage.setItem(THUMB_SIZE_KEY, String(state.thumbSize));
        } catch (_) {}
    }
    function setBadge(kind, text) {
        if (!badge) return;
        badge.className = `badge ${kind}`;
        badge.textContent = text;
    }

    function setStatus(text) {
        if (statusEl) statusEl.textContent = String(text || "");
    }

    function joinPath(base, name) {
        if (!base) return String(name || "");
        return `${base}/${name || ""}`;
    }

    function parentPath(p) {
        p = String(p || "");
        if (!p) return "";
        const i = p.lastIndexOf("/");
        return i < 0 ? "" : p.slice(0, i);
    }
    function normalizeRelPath(p) {
        p = String(p || "").replace(/\\/g, "/").trim();
        p = p.replace(/^\/+/, "").replace(/\/+$/, "");

        if (!p) return "";

        const parts = [];
        for (const part of p.split("/")) {
            if (!part || part === ".") continue;
            if (part === "..") {
                if (parts.length) parts.pop();
                continue;
            }
            parts.push(part);
        }

        return parts.join("/");
    }

    function setCurrentPath(nextPath, reason = "") {
        const prev = String(state.curPath || "");
        const norm = normalizeRelPath(nextPath);

        console.debug("[photogallery path]", {
            reason,
            prev,
            next: String(nextPath || ""),
            normalized: norm
        });

        state.curPath = norm;
        return state.curPath;
    }
    function currentRelPathFor(item) {
        if (!item) return "";
        if (item.rel_path) return String(item.rel_path);
        if (item.path) return String(item.path);
        if (item.base_path) return joinPath(String(item.base_path || ""), item.name || "");
        return joinPath(state.curPath, item.name);
    }

    function fmtSize(n) {
        const u = ["B", "KiB", "MiB", "GiB", "TiB"];
        let v = Number(n || 0);
        let i = 0;
        while (v >= 1024 && i < u.length - 1) {
            v /= 1024;
            i++;
        }
        return i === 0 ? `${v | 0} ${u[i]}` : `${v.toFixed(1)} ${u[i]}`;
    }

    function fmtTime(unix) {
        const n = Number(unix || 0);
        if (!Number.isFinite(n) || n <= 0) return "";
        const d = new Date(n * 1000);
        const pad = (x) => String(x).padStart(2, "0");
        return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }

    function shorten(s, n) {
        s = String(s || "");
        return s.length <= n ? s : s.slice(0, Math.max(0, n - 1)) + "…";
    }
    function fileExtLower(name) {
        const s = String(name || "");
        const i = s.lastIndexOf(".");
        return i >= 0 ? s.slice(i + 1).toLowerCase() : "";
    }

    function isRawName(name) {
        return [
            "cr2", "cr3", "nef", "arw", "raf", "dng", "rw2", "orf"
        ].includes(fileExtLower(name));
    }

    function renderRawGlyph() {
        const wrap = document.createElement("div");
        wrap.className = "rawGlyph";
        wrap.innerHTML = `
      <div style="
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        gap:8px;
        width:100%;
        height:100%;
        padding:16px;
        text-align:center;
      ">
        <div style="
          font-size:34px;
          font-weight:900;
          opacity:.92;
          letter-spacing:.04em;
        ">RAW</div>
        <div style="
          font-size:12px;
          opacity:.72;
          font-family:var(--mono);
        ">Original camera file</div>
      </div>`;
        return wrap;
    }
    function escapeAttr(s) {
        return String(s || "").replace(/"/g, "&quot;");
    }

    function fileGetUrl(relPath) {
        return `/api/v4/files/get?path=${encodeURIComponent(relPath || "")}`;
    }

    function galleryThumbUrl(relPath, size = 320, mtimeUnix = 0) {
        const qs = new URLSearchParams();
        qs.set("path", relPath || "");
        qs.set("size", String(size));
        if (mtimeUnix) qs.set("v", String(mtimeUnix));
        return `/api/v4/gallery/thumb?${qs.toString()}`;
    }
    let thumbObserver = null;
    const observedThumbs = new Set();

    function clearObservedThumbs() {
        if (!thumbObserver) {
            observedThumbs.clear();
            return;
        }

        for (const img of observedThumbs) {
            try {
                thumbObserver.unobserve(img);
            } catch (_) {}
        }

        observedThumbs.clear();
    }

    function loadDeferredThumb(img) {
        if (!img) return;

        const src = img.dataset.thumbSrc || "";
        if (!src) return;

        delete img.dataset.thumbSrc;

        if (thumbObserver) {
            try {
                thumbObserver.unobserve(img);
            } catch (_) {}
            observedThumbs.delete(img);
        }

        img.src = src;
    }

    function getThumbObserver() {
        if (!("IntersectionObserver" in window)) return null;

        if (thumbObserver) return thumbObserver;

        thumbObserver = new IntersectionObserver((entries) => {
            for (const entry of entries) {
                if (!entry.isIntersecting) continue;
                loadDeferredThumb(entry.target);
            }
        }, {
            root: gridWrap || null,
            rootMargin: "900px 0px",
            threshold: 0.01
        });

        return thumbObserver;
    }

    function deferThumbLoad(img, src) {
        if (!img || !src) return;

        img.dataset.thumbSrc = src;

        const observer = getThumbObserver();
        if (!observer) {
            requestAnimationFrame(() => loadDeferredThumb(img));
            return;
        }

        observedThumbs.add(img);
        observer.observe(img);
    }
    function galleryListUrl(relPath) {
        if (!relPath) return "/api/v4/gallery/list";
        return `/api/v4/gallery/list?path=${encodeURIComponent(relPath)}`;
    }

    function galleryTreeStatsUrl(relPath, force = false) {
        const qs = new URLSearchParams();
        const path = normalizeRelPath(relPath || "");

        if (path) qs.set("path", path);
        if (force) qs.set("force", "1");

        const tail = qs.toString();
        return tail
            ? `/api/v4/gallery/tree_stats?${tail}`
            : "/api/v4/gallery/tree_stats";
    }

    function galleryRecursiveSearchUrl(relPath, force = false) {
        const qs = new URLSearchParams();
        const path = normalizeRelPath(relPath || "");

        if (path) qs.set("path", path);
        if (force) qs.set("force", "1");

        const tail = qs.toString();
        return tail
            ? `/api/v4/gallery/search?${tail}`
            : "/api/v4/gallery/search";
    }

    async function fetchJson(url, opts = {}) {
        const r = await fetch(url, {
            credentials: "include",
            cache: "no-store",
            ...opts
        });
        const j = await r.json().catch(() => null);
        if (!r.ok || !j || !j.ok) {
            const msg = j && (j.message || j.error)
                ? `${j.error || ""} ${j.message || ""}`.trim()
                : `HTTP ${r.status}`;
            throw new Error(msg || `HTTP ${r.status}`);
        }
        return j;
    }

    function isEndpointUnsupportedError(e) {
        const msg = String(e && e.message ? e.message : e).toLowerCase();

        return (
            msg.includes("http 404") ||
            msg.includes("not_found") ||
            msg.includes("not found") ||
            msg.includes("unknown route") ||
            msg.includes("unknown endpoint")
        );
    }

    function normalizeServerSearchItem(it, rootPath) {
        const root = normalizeRelPath(rootPath || "");
        const rel = normalizeRelPath(
            it?.rel_path ||
            it?.path ||
            joinPath(it?.base_path || root, it?.name || "")
        );

        const name =
            it?.name ||
            rel.split("/").filter(Boolean).pop() ||
            rel ||
            "(unnamed)";

        const base = normalizeRelPath(it?.base_path || parentPath(rel));

        return {
            ...it,
            type: "file",
            name,
            rel_path: rel,
            path: rel,
            base_path: base
        };
    }

    async function fetchServerTreeStats(rootPath, force = false) {
        if (serverTreeStatsSupported === false) {
            return null;
        }

        try {
            const j = await fetchJson(galleryTreeStatsUrl(rootPath, force));
            const s = j.stats || j.tree_stats || j;

            serverTreeStatsSupported = true;

            return {
                dirs: Number(s.dirs ?? s.folder_count ?? s.folders ?? 0) || 0,
                files: Number(s.files ?? s.file_count ?? s.photos ?? s.total_photos ?? 0) || 0,
                fileBytes: Number(s.fileBytes ?? s.file_bytes ?? s.total_bytes ?? s.bytes ?? 0) || 0
            };
        } catch (e) {
            if (isEndpointUnsupportedError(e)) {
                serverTreeStatsSupported = false;
                return null;
            }

            console.warn("[photogallery] server tree_stats failed, falling back to browser walk", e);
            return null;
        }
    }

    async function fetchServerRecursiveSearchItems(rootPath, force = false) {
        if (serverRecursiveSearchSupported === false) {
            return null;
        }

        try {
            const j = await fetchJson(galleryRecursiveSearchUrl(rootPath, force));
            const raw = filterInternalPqnasGalleryItems(Array.isArray(j.items) ? j.items : []);

            serverRecursiveSearchSupported = true;

            return raw
                .filter((it) => it && (!it.type || it.type === "file"))
                .map((it) => normalizeServerSearchItem(it, rootPath));
        } catch (e) {
            if (isEndpointUnsupportedError(e)) {
                serverRecursiveSearchSupported = false;
                return null;
            }

            console.warn("[photogallery] server recursive search failed, falling back to browser walk", e);
            return null;
        }
    }

    async function galleryMetaGet(relPath) {
        return fetchJson("/api/v4/gallery/meta/get", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify({ path: relPath })
        });
    }

    async function galleryMetaSet(relPath, payload) {
        return fetchJson("/api/v4/gallery/meta/set", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify({
                path: relPath,
                ...payload
            })
        });
    }
    function closeContextMenu() {
        if (!ctxMenu) return;
        ctxMenu.classList.remove("show");
        ctxMenu.setAttribute("aria-hidden", "true");
        ctxMenu.innerHTML = "";
    }

    function clamp(n, lo, hi) {
        return Math.max(lo, Math.min(hi, n));
    }

    function placeContextMenu(x, y) {
        if (!ctxMenu) return;

        ctxMenu.style.left = "0px";
        ctxMenu.style.top = "0px";
        ctxMenu.classList.add("show");

        const rect = ctxMenu.getBoundingClientRect();
        const pad = 8;

        const nx = clamp(x, pad, window.innerWidth - rect.width - pad);
        const ny = clamp(y, pad, window.innerHeight - rect.height - pad);

        ctxMenu.style.left = `${nx}px`;
        ctxMenu.style.top = `${ny}px`;
        ctxMenu.setAttribute("aria-hidden", "false");
    }

    function menuItem(label, onClick, opts = {}) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = `ctxItem${opts.danger ? " danger" : ""}`;
        b.textContent = label;
        b.addEventListener("click", () => {
            closeContextMenu();
            onClick();
        });
        return b;
    }

    function menuSep() {
        const d = document.createElement("div");
        d.className = "ctxSep";
        return d;
    }


    async function pgPromptModal(opts) {
        return new Promise((resolve) => {
            const options = opts || {};

            const modal = document.createElement("div");
            modal.className = "modal show";
            modal.setAttribute("role", "dialog");
            modal.setAttribute("aria-modal", "true");

            const card = document.createElement("div");
            card.className = "modalCard";
            card.style.width = "min(560px, calc(100vw - 24px))";

            const head = document.createElement("div");
            head.className = "modalHead";

            const headText = document.createElement("div");

            const title = document.createElement("div");
            title.className = "modalTitle";
            title.textContent = options.title || "Enter value";

            const sub = document.createElement("div");
            sub.className = "modalSub";
            sub.textContent = options.subtitle || "";

            headText.appendChild(title);
            if (sub.textContent) headText.appendChild(sub);
            head.appendChild(headText);

            const body = document.createElement("div");
            body.className = "modalBody";
            body.style.gridTemplateColumns = "1fr";

            const label = document.createElement("label");
            label.className = "k";
            label.textContent = options.label || "Name";

            const input = document.createElement("input");
            input.type = "text";
            input.value = options.value || "";
            input.placeholder = options.placeholder || "";
            input.autocomplete = "off";
            input.spellcheck = false;
            input.style.width = "100%";
            input.style.padding = "10px 12px";
            input.style.borderRadius = "12px";
            input.style.border = "1px solid var(--border2)";
            input.style.background = "rgba(0,0,0,0.22)";
            input.style.color = "var(--fg)";
            input.style.font = "inherit";
            input.style.fontFamily = "var(--mono)";

            const help = document.createElement("div");
            help.className = "v";
            help.style.opacity = "0.78";
            help.style.fontSize = "12px";
            help.textContent = options.help || "";

            const err = document.createElement("div");
            err.className = "v";
            err.style.display = "none";
            err.style.padding = "8px 10px";
            err.style.border = "1px solid rgba(var(--fail-rgb),0.35)";
            err.style.borderRadius = "12px";
            err.style.background = "rgba(var(--fail-rgb),0.10)";
            err.style.color = "var(--fg)";
            err.style.fontWeight = "850";

            body.appendChild(label);
            body.appendChild(input);
            if (help.textContent) body.appendChild(help);
            body.appendChild(err);

            const foot = document.createElement("div");
            foot.className = "modalFoot";

            const spacer = document.createElement("div");
            spacer.style.flex = "1 1 auto";

            const cancelBtn = document.createElement("button");
            cancelBtn.type = "button";
            cancelBtn.className = "btn secondary";
            cancelBtn.textContent = options.cancelText || "Cancel";

            const okBtn = document.createElement("button");
            okBtn.type = "button";
            okBtn.className = "btn";
            okBtn.textContent = options.confirmText || "OK";

            foot.appendChild(spacer);
            foot.appendChild(cancelBtn);
            foot.appendChild(okBtn);

            card.appendChild(head);
            card.appendChild(body);
            card.appendChild(foot);
            modal.appendChild(card);
            document.body.appendChild(modal);

            const showError = (text) => {
                err.textContent = text || "";
                err.style.display = text ? "block" : "none";
            };

            const finish = (value) => {
                document.removeEventListener("keydown", onKey, true);
                modal.remove();
                resolve(value);
            };

            const submit = () => {
                const raw = input.value || "";
                const value = raw.trim();

                if (options.required !== false && !value) {
                    showError(options.requiredMessage || "Name is required.");
                    input.focus();
                    return;
                }

                if (typeof options.validate === "function") {
                    const msg = options.validate(value, raw);
                    if (msg) {
                        showError(msg);
                        input.focus();
                        return;
                    }
                }

                finish(value);
            };

            const onKey = (ev) => {
                if (ev.key === "Escape") {
                    ev.preventDefault();
                    ev.stopPropagation();
                    finish(null);
                    return;
                }

                if (ev.key === "Enter") {
                    ev.preventDefault();
                    ev.stopPropagation();
                    submit();
                }
            };

            document.addEventListener("keydown", onKey, true);

            modal.addEventListener("click", (ev) => {
                if (ev.target === modal) finish(null);
            });

            cancelBtn.addEventListener("click", () => finish(null));
            okBtn.addEventListener("click", submit);

            window.setTimeout(() => {
                input.focus();
                input.select();
            }, 0);
        });
    }

    async function pgConfirmModal(opts) {
        return new Promise((resolve) => {
            const options = opts || {};

            const modal = document.createElement("div");
            modal.className = "modal show";
            modal.setAttribute("role", "dialog");
            modal.setAttribute("aria-modal", "true");

            const card = document.createElement("div");
            card.className = "modalCard";
            card.style.width = "min(560px, calc(100vw - 24px))";

            const head = document.createElement("div");
            head.className = "modalHead";

            const headText = document.createElement("div");

            const title = document.createElement("div");
            title.className = "modalTitle";
            title.textContent = options.title || "Confirm action";

            const sub = document.createElement("div");
            sub.className = "modalSub";
            sub.textContent = options.subtitle || "";

            headText.appendChild(title);
            if (sub.textContent) headText.appendChild(sub);
            head.appendChild(headText);

            const body = document.createElement("div");
            body.className = "modalBody";
            body.style.gridTemplateColumns = "130px 1fr";

            const rows = Array.isArray(options.rows) ? options.rows : [];
            for (const row of rows) {
                const k = document.createElement("div");
                k.className = "k";
                k.textContent = String(row.label || "");

                const v = document.createElement("div");
                v.className = row.mono ? "v mono" : "v";
                v.textContent = String(row.value || "");

                body.appendChild(k);
                body.appendChild(v);
            }

            if (options.note) {
                const note = document.createElement("div");
                note.className = "v";
                note.style.gridColumn = "1 / -1";
                note.style.opacity = "0.9";
                note.textContent = String(options.note || "");
                body.appendChild(note);
            }

            const foot = document.createElement("div");
            foot.className = "modalFoot";

            const spacer = document.createElement("div");
            spacer.style.flex = "1 1 auto";

            const cancelBtn = document.createElement("button");
            cancelBtn.type = "button";
            cancelBtn.className = "btn secondary";
            cancelBtn.textContent = options.cancelText || "Cancel";

            const okBtn = document.createElement("button");
            okBtn.type = "button";
            okBtn.className = "btn";
            okBtn.textContent = options.confirmText || "OK";

            if (options.danger) {
                okBtn.style.borderColor = "rgba(var(--fail-rgb),0.45)";
                okBtn.style.background = "rgba(var(--fail-rgb),0.14)";
                okBtn.style.color = "var(--fg)";
            }

            foot.appendChild(spacer);
            foot.appendChild(cancelBtn);
            foot.appendChild(okBtn);

            card.appendChild(head);
            card.appendChild(body);
            card.appendChild(foot);
            modal.appendChild(card);
            document.body.appendChild(modal);

            const finish = (value) => {
                document.removeEventListener("keydown", onKey, true);
                modal.remove();
                resolve(!!value);
            };

            const onKey = (ev) => {
                if (ev.key === "Escape") {
                    ev.preventDefault();
                    ev.stopPropagation();
                    finish(false);
                    return;
                }

                if (ev.key === "Enter") {
                    ev.preventDefault();
                    ev.stopPropagation();
                    finish(true);
                }
            };

            document.addEventListener("keydown", onKey, true);

            modal.addEventListener("click", (ev) => {
                if (ev.target === modal) finish(false);
            });

            cancelBtn.addEventListener("click", () => finish(false));
            okBtn.addEventListener("click", () => finish(true));

            window.setTimeout(() => {
                if (options.danger) cancelBtn.focus();
                else okBtn.focus();
            }, 0);
        });
    }

    async function pgAlertModal(opts) {
        return new Promise((resolve) => {
            const options = opts || {};

            const modal = document.createElement("div");
            modal.className = "modal show";
            modal.setAttribute("role", "dialog");
            modal.setAttribute("aria-modal", "true");

            const card = document.createElement("div");
            card.className = "modalCard";
            card.style.width = "min(560px, calc(100vw - 24px))";

            const head = document.createElement("div");
            head.className = "modalHead";

            const headText = document.createElement("div");

            const title = document.createElement("div");
            title.className = "modalTitle";
            title.textContent = options.title || pgT("common.notice", null, "Notice");

            const sub = document.createElement("div");
            sub.className = "modalSub";
            sub.textContent = options.subtitle || "";

            headText.appendChild(title);
            if (sub.textContent) headText.appendChild(sub);
            head.appendChild(headText);

            const body = document.createElement("div");
            body.className = "modalBody";
            body.style.gridTemplateColumns = "130px 1fr";

            const rows = Array.isArray(options.rows) ? options.rows : [];
            for (const row of rows) {
                const k = document.createElement("div");
                k.className = "k";
                k.textContent = String(row.label || "");

                const v = document.createElement("div");
                v.className = row.mono ? "v mono" : "v";
                v.textContent = String(row.value || "");

                body.appendChild(k);
                body.appendChild(v);
            }

            if (options.note) {
                const note = document.createElement("div");
                note.className = "v";
                note.style.gridColumn = "1 / -1";
                note.style.opacity = "0.9";
                note.style.whiteSpace = "pre-wrap";
                note.textContent = String(options.note || "");
                body.appendChild(note);
            }

            const foot = document.createElement("div");
            foot.className = "modalFoot";

            const spacer = document.createElement("div");
            spacer.style.flex = "1 1 auto";

            const okBtn = document.createElement("button");
            okBtn.type = "button";
            okBtn.className = "btn";
            okBtn.textContent = options.confirmText || pgT("common.ok", null, "OK");

            if (options.danger) {
                okBtn.style.borderColor = "rgba(var(--fail-rgb),0.45)";
                okBtn.style.background = "rgba(var(--fail-rgb),0.14)";
                okBtn.style.color = "var(--fg)";
            }

            foot.appendChild(spacer);
            foot.appendChild(okBtn);

            card.appendChild(head);
            if (rows.length || options.note) card.appendChild(body);
            card.appendChild(foot);
            modal.appendChild(card);
            document.body.appendChild(modal);

            const finish = () => {
                document.removeEventListener("keydown", onKey, true);
                modal.remove();
                resolve(true);
            };

            const onKey = (ev) => {
                if (ev.key === "Escape" || ev.key === "Enter") {
                    ev.preventDefault();
                    ev.stopPropagation();
                    finish();
                }
            };

            document.addEventListener("keydown", onKey, true);
            modal.addEventListener("click", (ev) => {
                if (ev.target === modal) finish();
            });
            okBtn.addEventListener("click", finish);

            window.setTimeout(() => okBtn.focus(), 0);
        });
    }

    async function renameImage(item) {
        if (!item || item.type !== "file") return;

        const oldRel = currentRelPathFor(item);
        const oldName = String(item.name || "");
        const newName = await pgPromptModal({
            title: "Rename image",
            subtitle: "Choose a new name for this image.",
            label: "New name",
            value: oldName,
            help: "Use only the file name, not a full path.",
            confirmText: "Rename",
            cancelText: "Cancel",
            validate(value) {
                if (!value) return "Name is required.";
                if (value === oldName) return "Name is unchanged.";
                if (value.includes("/") || value.includes("\\")) return "Name cannot contain path separators.";
                if (value === "." || value === "..") return "Invalid name.";
                return "";
            },
        });

        if (newName === null) return;

        const base = parentPath(oldRel);
        const newRel = base ? `${base}/${newName}` : newName;

        setBadge("warn", "working…");
        setStatus(`Renaming ${oldName}…`);

        try {
            const r = await fetch(
                `/api/v4/files/move?from=${encodeURIComponent(oldRel)}&to=${encodeURIComponent(newRel)}`,
                {
                    method: "POST",
                    credentials: "include",
                    cache: "no-store"
                }
            );

            const j = await r.json().catch(() => null);
            if (!r.ok || !j || !j.ok) {
                const msg = j && (j.message || j.error)
                    ? `${j.error || ""} ${j.message || ""}`.trim()
                    : `HTTP ${r.status}`;
                throw new Error(msg || `HTTP ${r.status}`);
            }

            if (state.previewPath === oldRel) {
                closePreviewModal();
            }
            if (state.editingPath === oldRel) {
                closeMetaModal();
            }

            setBadge("ok", "ready");
            setStatus(`Renamed: ${oldName} → ${newName}`);
            clearFolderListCache();
            resetTreeStats();
            invalidateSearchCache();
            await load(true);
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Rename failed: ${String(e && e.message ? e.message : e)}`);
        }
    }

    async function deleteImage(item) {
        if (!item || item.type !== "file") return;

        const rel = currentRelPathFor(item);
        const ok = await pgConfirmModal({
            title: "Move image to trash?",
            subtitle: "The selected image will be moved to Trash.",
            rows: [
                { label: "Image", value: rel, mono: true },
            ],
            note: "You can restore it later from Trash until it is permanently deleted.",
            confirmText: "Move to trash",
            cancelText: "Cancel",
            danger: true,
        });
        if (!ok) return;

        setBadge("warn", "working…");
        setStatus(`Moving ${item.name} to trash…`);

        try {
            const r = await fetch(
                `/api/v4/files/delete?path=${encodeURIComponent(rel)}`,
                {
                    method: "POST",
                    credentials: "include",
                    cache: "no-store"
                }
            );

            const j = await r.json().catch(() => null);
            if (!r.ok || !j || !j.ok) {
                const msg = j && (j.message || j.error)
                    ? `${j.error || ""} ${j.message || ""}`.trim()
                    : `HTTP ${r.status}`;
                throw new Error(msg || `HTTP ${r.status}`);
            }

            if (state.previewPath === rel) {
                closePreviewModal();
            }
            if (state.editingPath === rel) {
                closeMetaModal();
            }

            setBadge("ok", "ready");
            setStatus(`Moved to trash: ${item.name}`);
            clearFolderListCache();
            resetTreeStats();
            invalidateSearchCache();
            await load(true);
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Move to trash failed: ${String(e && e.message ? e.message : e)}`);
        }
    }
    async function renameFolder(item) {
        if (!item || item.type !== "dir") return;

        const oldRel = currentRelPathFor(item);
        const oldName = String(item.name || "");
        const newName = await pgPromptModal({
            title: "Rename folder",
            subtitle: "Choose a new name for this folder.",
            label: "New name",
            value: oldName,
            help: "Use only the folder name, not a full path.",
            confirmText: "Rename",
            cancelText: "Cancel",
            validate(value) {
                if (!value) return "Name is required.";
                if (value === oldName) return "Name is unchanged.";
                if (value.includes("/") || value.includes("\\")) return "Name cannot contain path separators.";
                if (value === "." || value === "..") return "Invalid name.";
                return "";
            },
        });

        if (newName === null) return;

        const base = parentPath(oldRel);
        const newRel = base ? `${base}/${newName}` : newName;

        setBadge("warn", "working…");
        setStatus(`Renaming folder ${oldName}…`);

        try {
            const r = await fetch(
                `/api/v4/files/move?from=${encodeURIComponent(oldRel)}&to=${encodeURIComponent(newRel)}`,
                {
                    method: "POST",
                    credentials: "include",
                    cache: "no-store"
                }
            );

            const j = await r.json().catch(() => null);
            if (!r.ok || !j || !j.ok) {
                const msg = j && (j.message || j.error)
                    ? `${j.error || ""} ${j.message || ""}`.trim()
                    : `HTTP ${r.status}`;
                throw new Error(msg || `HTTP ${r.status}`);
            }

            setBadge("ok", "ready");
            setStatus(`Renamed folder: ${oldName} → ${newName}`);
            clearFolderListCache();
            resetTreeStats();
            invalidateSearchCache();
            await load(true);
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Folder rename failed: ${String(e && e.message ? e.message : e)}`);
        }
    }


    function basenameFromRelPath(relPath) {
        const parts = normalizeRelPath(relPath).split("/").filter(Boolean);
        return parts.length ? parts[parts.length - 1] : "";
    }

    function itemTypeForRelPath(relPath) {
        const norm = normalizeRelPath(relPath);

        for (const tile of gridEl.querySelectorAll(".tile")) {
            if (normalizeRelPath(tile.dataset.relPath || "") === norm) {
                const t = String(tile.dataset.itemType || "");
                if (t === "file" || t === "dir") return t;
            }
        }

        for (const it of state.items || []) {
            if (normalizeRelPath(currentRelPathFor(it)) === norm) {
                const t = String(it.type || "");
                if (t === "file" || t === "dir") return t;
            }
        }

        return "file";
    }

    function isSameOrUnderPath(path, root) {
        const p = normalizeRelPath(path);
        const r = normalizeRelPath(root);
        return !!r && (p === r || p.startsWith(r + "/"));
    }

    function dedupeSelectedMovePaths(paths) {
        const sorted = paths
            .map((p) => normalizeRelPath(p))
            .filter(Boolean)
            .sort((a, b) => a.localeCompare(b));

        const out = [];
        for (const p of sorted) {
            if (!out.some((parent) => p === parent || p.startsWith(parent + "/"))) {
                out.push(p);
            }
        }
        return out;
    }

    async function movePathApi(fromRel, toRel) {
        const r = await fetch(
            `/api/v4/files/move?from=${encodeURIComponent(fromRel)}&to=${encodeURIComponent(toRel)}`,
            {
                method: "POST",
                headers: { "Accept": "application/json" },
                cache: "no-store"
            }
        );

        const j = await r.json().catch(() => ({}));
        if (!r.ok || !j || j.ok === false) {
            throw new Error(j.message || j.error || `HTTP ${r.status}`);
        }
        return j;
    }

    async function confirmMoveMayBreakShares(targets) {
        let shares = [];
        try {
            const r = await fetch("/api/v4/shares/list", {
                headers: { "Accept": "application/json" },
                cache: "no-store"
            });
            const j = await r.json().catch(() => ({}));
            if (r.ok && j && j.ok && Array.isArray(j.shares)) {
                shares = j.shares;
            }
        } catch (_) {
            // Share warning is best-effort only. The move itself should still be usable.
            return true;
        }

        const affected = [];

        for (const s of shares) {
            const sharePath = normalizeRelPath(String(s.path || ""));
            const shareType = String(s.type || "");
            if (!sharePath || shareType === "album") continue;

            for (const t of targets) {
                const from = normalizeRelPath(t.from || "");
                const type = String(t.type || "file");
                if (!from) continue;

                if (sharePath === from || (type === "dir" && sharePath.startsWith(from + "/"))) {
                    const mode = String(s.mode || s.share_mode || "");
                    const pq = mode.includes("pq") || !!s.invite_url || !!s.recipient_count || Array.isArray(s.recipients);
                    affected.push({
                        path: sharePath,
                        type: shareType,
                        pq
                    });
                    break;
                }
            }
        }

        if (!affected.length) return true;

        const shown = affected
            .slice(0, 8)
            .map((x) => `• ${x.pq ? "PQ " : ""}${x.type}: ${x.path}`)
            .join("\n");

        const more = affected.length > 8 ? `\n…plus ${affected.length - 8} more` : "";

        return await pgConfirmModal({
            title: pgT("photogallery.move.share_warning_title", null, "Move affects share links"),
            subtitle: pgT("photogallery.move.share_warning_subtitle", { count: affected.length }, "{count} existing share link(s) may break."),
            rows: [
                { label: pgT("photogallery.move.affected", null, "Affected"), value: String(affected.length), mono: true },
            ],
            note: `${shown}${more}\n\n${pgT("photogallery.move.share_warning_note", null, "Those path-based share links will no longer find the moved content after the move.")}`,
            confirmText: pgT("common.continue", null, "Continue"),
            cancelText: pgT("common.cancel", null, "Cancel"),
            danger: true,
        });
    }


    async function pickMoveDestination(options) {
        const o = options || {};
        const fallbackPrompt = async () => {
            const raw = await pgPromptModal({
                title: o.title || pgT("photogallery.move.title", null, "Move"),
                subtitle: pgT("photogallery.move.prompt_destination_subtitle", null, "Enter destination folder path relative to My Files."),
                label: pgT("photogallery.move.destination_folder", null, "Destination folder"),
                value: o.initialPath || "",
                help: pgT("photogallery.move.leave_empty_for_root", null, "Leave empty for root."),
                confirmText: pgT("photogallery.move.move_here", null, "Move here"),
                cancelText: pgT("common.cancel", null, "Cancel"),
                required: false,
            });
            return raw === null ? null : normalizeRelPath(raw);
        };

        const picker = window.PQNAS_FOLDER_PICKER;
        if (!picker || typeof picker.open !== "function") {
            return fallbackPrompt();
        }

        try {
            const picked = await picker.open({
                title: o.title || pgT("photogallery.move.title", null, "Move"),
                subtitle: pgT("photogallery.move.choose_destination_folder", null, "Choose destination folder"),
                source: o.source || "",
                initialPath: o.initialPath || "",
                blockedPaths: Array.isArray(o.blockedPaths) ? o.blockedPaths : [],
                chooseLabel: o.chooseLabel || pgT("photogallery.move.move_here", null, "Move here"),
                canCreate: true
            });
            return picked === null ? null : normalizeRelPath(picked);
        } catch (e) {
            console.warn("Folder picker failed, falling back to prompt:", e);
            return fallbackPrompt();
        }
    }

    async function moveItem(item) {
        if (!item) return;

        const fromRel = normalizeRelPath(currentRelPathFor(item));
        if (!fromRel) return;

        const name = basenameFromRelPath(fromRel);
        if (!name) return;

        const currentParent = parentPath(fromRel);
        const destDir = await pickMoveDestination({
            title: pgT("photogallery.move.move_kind", {
                kind: item.type === "dir"
                    ? pgT("photogallery.folder", null, "folder")
                    : pgT("photogallery.image", null, "image")
            }, "Move {kind}"),
            source: fromRel,
            initialPath: currentParent,
            blockedPaths: item.type === "dir" ? [fromRel] : [],
            chooseLabel: pgT("photogallery.move.move_here", null, "Move here")
        });

        if (destDir === null) {
            setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
            return;
        }
        const toRel = destDir ? joinPath(destDir, name) : name;

        if (!toRel || toRel === fromRel) {
            setStatus(pgT("photogallery.move.cancelled_same_destination", null, "Move cancelled: destination is the same."));
            return;
        }

        if (item.type === "dir" && isSameOrUnderPath(destDir, fromRel)) {
            await pgAlertModal({
                title: pgT("photogallery.move.cannot_move_folder_into_itself", null, "Cannot move a folder into itself."),
                confirmText: pgT("common.ok", null, "OK"),
                danger: true,
            });
            setStatus(pgT("photogallery.move.cancelled_inside_source", null, "Move cancelled: destination is inside source folder."));
            return;
        }

        const targets = [{ from: fromRel, to: toRel, type: item.type || "file" }];
        if (!(await confirmMoveMayBreakShares(targets))) {
            setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
            return;
        }

        if (!(await pgConfirmModal({
            title: pgT("photogallery.move.confirm_single_title", null, "Move item?"),
            rows: [
                { label: pgT("photogallery.move.from", null, "From"), value: fromRel, mono: true },
                { label: pgT("photogallery.move.to", null, "To"), value: toRel, mono: true },
            ],
            confirmText: pgT("photogallery.move.move_here", null, "Move here"),
            cancelText: pgT("common.cancel", null, "Cancel"),
        }))) {
            setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
            return;
        }

        try {
            setBadge("warn", "moving…");
            setStatus(pgT("photogallery.move.moving_name", { name }, "Moving {name}…"));
            await movePathApi(fromRel, toRel);

            selectedRelPaths.delete(fromRel);
            selectedRelPaths.add(toRel);
            selectionAnchorRelPath = toRel;

            setStatus(pgT("photogallery.move.moved_from_to", { from: fromRel, to: toRel }, "Moved: {from} → {to}"));
            await load(true);
        } catch (e) {
            setBadge("err", pgT("photogallery.badge.move_failed", null, "move failed"));
            setStatus(pgT("photogallery.move.failed", { error: String(e && e.message ? e.message : e) }, "Move failed: {error}"));
        }
    }

    async function moveSelection() {
        const paths = dedupeSelectedMovePaths(selectedRelPathsList());
        if (!paths.length) {
            setStatus(pgT("photogallery.nothing_selected", null, "Nothing selected."));
            return;
        }

        const destDir = await pickMoveDestination({
            title: pgT("photogallery.move.move_selected_count", { count: paths.length }, "Move {count} selected item(s)"),
            source: pgT("photogallery.selected_item_count", { count: paths.length }, "{count} selected item(s)"),
            initialPath: state.curPath || "",
            blockedPaths: paths.filter((p) => itemTypeForRelPath(p) === "dir"),
            chooseLabel: pgT("photogallery.move.move_here", null, "Move here")
        });

        if (destDir === null) {
            setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
            return;
        }

        const targets = [];

        for (const from of paths) {
            const name = basenameFromRelPath(from);
            if (!name) continue;

            const type = itemTypeForRelPath(from);
            const to = destDir ? joinPath(destDir, name) : name;

            if (!to || to === from) continue;

            if (type === "dir" && isSameOrUnderPath(destDir, from)) {
                await pgAlertModal({
                    title: pgT("photogallery.move.cannot_move_folder_into_itself", null, "Cannot move a folder into itself."),
                    rows: [
                        { label: pgT("photogallery.folder", null, "Folder"), value: from, mono: true },
                    ],
                    confirmText: pgT("common.ok", null, "OK"),
                    danger: true,
                });
                setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
                return;
            }

            targets.push({ from, to, type });
        }

        if (!targets.length) {
            setStatus(pgT("photogallery.move.cancelled_already_there", null, "Move cancelled: everything is already in that destination."));
            return;
        }

        const seenDest = new Set();
        for (const t of targets) {
            if (seenDest.has(t.to)) {
                await pgAlertModal({
                    title: pgT("photogallery.move.duplicate_destination_title", null, "Duplicate destination"),
                    subtitle: pgT("photogallery.move.duplicate_destination_subtitle", null, "Multiple selected items would land on the same destination."),
                    rows: [
                        { label: pgT("photogallery.move.destination_folder", null, "Destination folder"), value: t.to, mono: true },
                    ],
                    confirmText: pgT("common.ok", null, "OK"),
                    danger: true,
                });
                setStatus(pgT("photogallery.move.cancelled_duplicate_destination", null, "Move cancelled: duplicate destination."));
                return;
            }
            seenDest.add(t.to);
        }

        if (!(await confirmMoveMayBreakShares(targets))) {
            setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
            return;
        }

        if (!(await pgConfirmModal({
            title: pgT("photogallery.move.confirm_selected_title", { count: targets.length }, "Move {count} selected item(s)?"),
            rows: [
                { label: pgT("photogallery.move.destination_folder", null, "Destination folder"), value: destDir || "/", mono: true },
            ],
            confirmText: pgT("photogallery.move.move_here", null, "Move here"),
            cancelText: pgT("common.cancel", null, "Cancel"),
        }))) {
            setStatus(pgT("photogallery.move.cancelled", null, "Move cancelled."));
            return;
        }

        setBadge("warn", "moving…");
        setStatus(pgT("photogallery.move.moving_selected_count", { count: targets.length }, "Moving {count} selected item(s)…"));

        let done = 0;
        const failed = [];

        for (const t of targets) {
            try {
                await movePathApi(t.from, t.to);
                done += 1;
            } catch (e) {
                failed.push({
                    from: t.from,
                    to: t.to,
                    error: String(e && e.message ? e.message : e)
                });
            }
        }

        selectedRelPaths.clear();
        selectionAnchorRelPath = "";
        if (typeof updateSelectionUi === "function") updateSelectionUi();

        await load(true);

        if (failed.length) {
            console.warn("Photo Gallery moveSelection failures:", failed);
            setBadge("warn", pgT("photogallery.badge.partial_move", null, "partial move"));
            setStatus(pgT("photogallery.move.partial_result", { done, total: targets.length, failed: failed.length }, "Moved {done}/{total}. Failed: {failed}"));
            await pgAlertModal({
                title: pgT("photogallery.move.partial_move_title", null, "Partial move"),
                subtitle: pgT("photogallery.move.partial_alert_header", { done, total: targets.length }, "Moved {done}/{total} item(s)."),
                note: failed.slice(0, 8).map((f) => `• ${f.from}: ${f.error}`).join("\n"),
                confirmText: pgT("common.ok", null, "OK"),
                danger: true,
            });
        } else {
            setBadge("ok", pgT("photogallery.badge.moved", null, "moved"));
            setStatus(pgT("photogallery.move.moved_selected_count", { count: done }, "Moved {count} selected item(s)."));
        }
    }


    async function deleteFolder(item) {
        if (!item || item.type !== "dir") return;

        const rel = currentRelPathFor(item);
        const ok = await pgConfirmModal({
            title: pgT("photogallery.trash.confirm_folder_title", null, "Move folder to trash?"),
            subtitle: pgT("photogallery.trash.confirm_folder_subtitle", null, "This moves the folder and its contents to Trash."),
            rows: [
                { label: pgT("photogallery.folder", null, "Folder"), value: rel, mono: true },
            ],
            note: pgT("photogallery.trash.restore_later_note", null, "You can restore it later from Trash."),
            confirmText: pgT("photogallery.trash.move_to_trash", null, "Move to trash"),
            cancelText: pgT("common.cancel", null, "Cancel"),
            danger: true,
        });
        if (!ok) return;

        setBadge("warn", "working…");
        setStatus(pgT("photogallery.trash.moving_folder", { name: item.name }, "Moving folder {name} to trash…"));

        try {
            const r = await fetch(
                `/api/v4/files/delete?path=${encodeURIComponent(rel)}`,
                {
                    method: "POST",
                    credentials: "include",
                    cache: "no-store"
                }
            );

            const j = await r.json().catch(() => null);
            if (!r.ok || !j || !j.ok) {
                const msg = j && (j.message || j.error)
                    ? `${j.error || ""} ${j.message || ""}`.trim()
                    : `HTTP ${r.status}`;
                throw new Error(msg || `HTTP ${r.status}`);
            }

            setBadge("ok", "ready");
            setStatus(pgT("photogallery.trash.moved_folder", { name: item.name }, "Moved folder to trash: {name}"));
            clearFolderListCache();
            resetTreeStats();
            invalidateSearchCache();
            await load(true);
        } catch (e) {
            setBadge("err", "error");
            setStatus(pgT("photogallery.trash.folder_failed", { error: String(e && e.message ? e.message : e) }, "Folder move to trash failed: {error}"));
        }
    }
    async function createFolder(basePath = state.curPath) {
        const shownBase = basePath ? `/${basePath}` : "/";
        const name = await pgPromptModal({
            title: "New folder",
            subtitle: `Create a folder in ${shownBase}.`,
            label: "Folder name",
            value: "New Folder",
            help: "Use only the folder name, not a full path.",
            confirmText: "Create folder",
            cancelText: "Cancel",
            validate(value) {
                if (!value) return "Folder name is required.";
                if (value.includes("/") || value.includes("\\")) return "Folder name cannot contain path separators.";
                if (value === "." || value === "..") return "Invalid folder name.";
                return "";
            },
        });

        if (name === null) return;

        const rel = basePath ? `${basePath}/${name}` : name;

        setBadge("warn", "working…");
        setStatus(`Creating folder ${name}…`);

        try {
            const r = await fetch(
                `/api/v4/files/mkdir?path=${encodeURIComponent(rel)}`,
                {
                    method: "POST",
                    credentials: "include",
                    cache: "no-store"
                }
            );

            const j = await r.json().catch(() => null);
            if (!r.ok || !j || !j.ok) {
                const msg = j && (j.message || j.error)
                    ? `${j.error || ""} ${j.message || ""}`.trim()
                    : `HTTP ${r.status}`;
                throw new Error(msg || `HTTP ${r.status}`);
            }

            setBadge("ok", "ready");
            setStatus(`Created folder: ${name}`);
            clearFolderListCache();
            resetTreeStats();
            invalidateSearchCache();
            await load(true);
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Create folder failed: ${String(e && e.message ? e.message : e)}`);
        }
    }
    function openSelectionContextMenu(x, y) {
        if (!ctxMenu) return;

        const count = selectedRelPaths.size;
        if (!count) return;

        const imageTargets = selectedImageRelPaths();

        ctxMenu.innerHTML = "";

        if (imageTargets.length) {
            if (imageTargets.length === 2 &&
                window.PQNAS_PHOTOGALLERY &&
                window.PQNAS_PHOTOGALLERY.compareView &&
                typeof window.PQNAS_PHOTOGALLERY.compareView.open === "function") {
                ctxMenu.appendChild(menuItem(pgT("photogallery.menu.compare_side_by_side", null, "Compare side by side"), () => {
                    window.PQNAS_PHOTOGALLERY.compareView.open(imageTargets);
                }));
            }

            ctxMenu.appendChild(menuItem(pgT("photogallery.menu.add_selected_to_album", null, "Add selected photos to album…"), () => {
                addSelectedImagesToAlbum();
            }));

            ctxMenu.appendChild(menuItem(pgT("photogallery.menu.edit_selected_metadata", null, "Edit metadata for selected photos…"), () => {
                const preferred =
                    state.activeTilePath && imageTargets.includes(state.activeTilePath)
                        ? state.activeTilePath
                        : imageTargets[0];

                openMetaFor(preferred);
            }));
            ctxMenu.appendChild(menuSep());
        }

        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.download_selected", null, "Download selected"), () => downloadSelectionZip()));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.export_selected_metadata", null, "Export selected with metadata…"), () => exportSelectionZip()));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.move_selected", null, "Move selected…"), () => moveSelection()));
        ctxMenu.appendChild(menuSep());
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.clear_selection", null, "Clear selection"), () => {
            clearSelection();
            setStatus(pgT("photogallery.selection_cleared", null, "Selection cleared."));
        }));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.move_selected_to_trash", null, "Move selected to trash…"), () => deleteSelection(), { danger: true }));

        placeContextMenu(x, y);
    }
    function openFolderContextMenu(x, y, item) {
        if (!ctxMenu || !item || item.type !== "dir") return;

        ctxMenu.innerHTML = "";
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.open", null, "Open"), () => {
            setCurrentPath(currentRelPathFor(item), "folder-context-open");
            load();
        }));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.new_folder_here", null, "New folder here…"), () => {
            createFolder(currentRelPathFor(item));
        }));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.download_zip", null, "Download zip"), () => downloadSingleFolderZip(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.export_metadata", null, "Export with metadata…"), () => exportSingleItemZip(item)));
        ctxMenu.appendChild(menuSep());
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.move", null, "Move…"), () => moveItem(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.rename", null, "Rename…"), () => renameFolder(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.move_to_trash", null, "Move to trash…"), () => deleteFolder(item), { danger: true }));

        placeContextMenu(x, y);
    }
    function openBackgroundContextMenu(x, y) {
        if (!ctxMenu) return;

        ctxMenu.innerHTML = "";

        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.upload_files", null, "Upload files…"), () => {
            if (window.PQNAS_PHOTOGALLERY?.upload?.pickFiles) {
                window.PQNAS_PHOTOGALLERY.upload.pickFiles();
                return;
            }
            if (window.PQNAS_PHOTOGALLERY_UPLOAD?.pickFiles) {
                window.PQNAS_PHOTOGALLERY_UPLOAD.pickFiles();
                return;
            }
            setBadge("err", "error");
            setStatus(pgT("photogallery.upload_module_not_loaded", null, "Upload module not loaded."));
        }));

        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.upload_folder", null, "Upload folder…"), () => {
            if (window.PQNAS_PHOTOGALLERY?.upload?.pickFolder) {
                window.PQNAS_PHOTOGALLERY.upload.pickFolder();
                return;
            }
            if (window.PQNAS_PHOTOGALLERY_UPLOAD?.pickFolder) {
                window.PQNAS_PHOTOGALLERY_UPLOAD.pickFolder();
                return;
            }
            setBadge("err", "error");
            setStatus(pgT("photogallery.upload_module_not_loaded", null, "Upload module not loaded."));
        }));

        ctxMenu.appendChild(menuSep());

        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.new_folder", null, "New folder…"), () => {
            createFolder(state.curPath);
        }));

        if (state.curPath) {
            ctxMenu.appendChild(menuItem(pgT("common.up", null, "Up"), () => {
                setCurrentPath(parentPath(state.curPath), "background-context-up");
                clearSelection();
                load();
            }));
        }

        ctxMenu.appendChild(menuSep());
        ctxMenu.appendChild(menuItem(pgT("common.refresh", null, "Refresh"), () => load(true)));

        placeContextMenu(x, y);
    }
    function openImageContextMenu(x, y, item) {
        if (!ctxMenu || !item || item.type !== "file") return;

        const rel = currentRelPathFor(item);
        const shareLabel =
            window.PQNAS_PHOTOGALLERY_SHARES?.menuLabelForRelPath(rel, "file") ||
            "Share link…";

        ctxMenu.innerHTML = "";
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.open_preview", null, "Open preview"), () => openPreviewFor(item)));

        if (hasUsableGps(item)) {
            ctxMenu.appendChild(menuItem(
                pgT("photogallery.menu.show_on_map", null, "Show on map"),
                () => showItemOnMap(item)
            ));
        }

        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.add_to_album", null, "Add to album…"), () => {
            const rel = currentRelPathFor(item);
            setSingleSelection(rel);
            addSelectedImagesToAlbum();
        }));

        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.edit_metadata", null, "Edit metadata…"), () => openMetaFor(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.download", null, "Download"), () => downloadSingleImage(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.export_metadata", null, "Export with metadata…"), () => exportSingleItemZip(item)));
        ctxMenu.appendChild(menuItem(shareLabel, () => {
            window.PQNAS_PHOTOGALLERY_SHARES?.openForItem(item);
        }));
        ctxMenu.appendChild(menuSep());
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.move", null, "Move…"), () => moveItem(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.rename", null, "Rename…"), () => renameImage(item)));
        ctxMenu.appendChild(menuItem(pgT("photogallery.menu.move_to_trash", null, "Move to trash…"), () => deleteImage(item), { danger: true }));

        placeContextMenu(x, y);
    }
    function placeMetaCentered() {
        if (!metaCard) return;
        metaCard.style.transform = "translateX(-50%)";
        metaCard.style.left = "50%";
        metaCard.style.top = "110px";
    }

    function clampMetaIntoViewport() {
        if (!metaCard) return;

        const rect = metaCard.getBoundingClientRect();
        const pad = 8;

        let left = rect.left;
        let top = rect.top;

        const maxLeft = Math.max(pad, window.innerWidth - rect.width - pad);
        const maxTop = Math.max(pad, window.innerHeight - rect.height - pad);

        left = clamp(left, pad, maxLeft);
        top = clamp(top, pad, maxTop);

        metaCard.style.transform = "none";
        metaCard.style.left = `${left}px`;
        metaCard.style.top = `${top}px`;
    }
    function updateSelectionUi() {
        const count = selectedRelPaths.size;

        if (selCount) {
            selCount.textContent = `${count} selected`;
            selCount.style.display = count > 0 ? "" : "none";
        }

        if (downloadSelBtn) downloadSelBtn.disabled = count === 0;
        if (deleteSelBtn) deleteSelBtn.disabled = count === 0;
        if (clearSelBtn) clearSelBtn.disabled = count === 0;

        refreshMetaApplySelectionUi();
        refreshFooterStats();
    }
    function clearSelectionDom() {
        if (!gridEl) return;
        for (const el of gridEl.querySelectorAll(".tile")) {
            el.classList.remove("sel");
        }
    }

    function applySelectionToDom() {
        if (!gridEl) return;
        for (const el of gridEl.querySelectorAll(".tile")) {
            const rel = String(el.dataset.relPath || "");
            el.classList.toggle("sel", selectedRelPaths.has(rel));
        }
        updateSelectionUi();
    }

    function visibleRelPathsInOrder() {
        if (!gridEl) return [];
        return Array.from(gridEl.querySelectorAll(".tile"))
            .map((el) => String(el.dataset.relPath || ""))
            .filter(Boolean);
    }

    function clearSelection() {
        selectedRelPaths.clear();
        selectionAnchorRelPath = "";
        state.activeTilePath = "";
        clearSelectionDom();
        updateTileSelection();
        updateSelectionUi();
    }

    function setSingleSelection(relPath, opts = {}) {
        if (!relPath) return;
        selectedRelPaths = new Set([relPath]);
        selectionAnchorRelPath = relPath;
        applySelectionToDom();
        setActiveTileRelPath(relPath, {
            scroll: opts.scroll === true,
            focus: opts.focus === true
        });
    }

    function toggleSelection(relPath) {
        if (!relPath) return;
        if (selectedRelPaths.has(relPath)) selectedRelPaths.delete(relPath);
        else selectedRelPaths.add(relPath);
        applySelectionToDom();
        setActiveTileRelPath(relPath, {
            scroll: false,
            focus: false
        });
    }
    function ensureSelected(relPath) {
        if (!relPath) return;
        if (!selectedRelPaths.has(relPath)) {
            setSingleSelection(relPath);
        }
    }

    function selectRange(fromRelPath, toRelPath, additive) {
        const keys = visibleRelPathsInOrder();
        const a = keys.indexOf(String(fromRelPath || ""));
        const b = keys.indexOf(String(toRelPath || ""));

        if (a < 0 || b < 0) {
            setSingleSelection(String(toRelPath || fromRelPath || ""));
            selectionAnchorRelPath = String(toRelPath || fromRelPath || "");
            return;
        }

        const lo = Math.min(a, b);
        const hi = Math.max(a, b);

        const next = additive ? new Set(selectedRelPaths) : new Set();
        for (let i = lo; i <= hi; i++) {
            if (keys[i]) next.add(keys[i]);
        }

        selectedRelPaths = next;
        selectionAnchorRelPath = String(toRelPath || "");
        applySelectionToDom();
        setActiveTileRelPath(String(toRelPath || ""), {
            scroll: false,
            focus: false
        });
    }

    function selectedRelPathsList() {
        return Array.from(selectedRelPaths).sort((a, b) => String(a).localeCompare(String(b)));
    }
    function selectedImageRelPaths() {
        if (!gridEl) return [];

        return Array.from(gridEl.querySelectorAll(".tile[data-item-type='file']"))
            .map((tile) => String(tile.dataset.relPath || ""))
            .filter((rel) => rel && selectedRelPaths.has(rel))
            .sort((a, b) => String(a).localeCompare(String(b)));
    }

    let albumsViewLoadPromise = null;

    function ensureAlbumsViewLoaded() {
        if (window.PQNAS_PHOTOGALLERY?.albumsView) {
            return Promise.resolve(window.PQNAS_PHOTOGALLERY.albumsView);
        }

        if (albumsViewLoadPromise) return albumsViewLoadPromise;

        albumsViewLoadPromise = new Promise((resolve, reject) => {
            const existing = document.querySelector('script[data-pqnas-albums-view="1"]');
            if (existing) {
                existing.addEventListener("load", () => {
                    if (window.PQNAS_PHOTOGALLERY?.albumsView) {
                        resolve(window.PQNAS_PHOTOGALLERY.albumsView);
                    } else {
                        reject(new Error("albums_view.js loaded but did not register albumsView"));
                    }
                }, { once: true });

                existing.addEventListener("error", () => {
                    reject(new Error("albums_view.js failed to load"));
                }, { once: true });

                return;
            }

            const s = document.createElement("script");
            s.src = "./albums_view.js?v=20260519-pg-albums-view-i18n-1";
            s.async = false;
            s.dataset.pqnasAlbumsView = "1";

            s.onload = () => {
                if (window.PQNAS_PHOTOGALLERY?.albumsView) {
                    resolve(window.PQNAS_PHOTOGALLERY.albumsView);
                } else {
                    reject(new Error("albums_view.js loaded but did not register albumsView"));
                }
            };

            s.onerror = () => {
                reject(new Error("albums_view.js failed to load"));
            };

            document.body.appendChild(s);
        });

        return albumsViewLoadPromise;
    }

    function openPreviewByRelPath(relPath) {
        relPath = String(relPath || "");
        if (!relPath) return;

        const all = [...state.items, ...state.searchItems];

        let item = all.find((it) =>
            it &&
            it.type === "file" &&
            currentRelPathFor(it) === relPath
        );

        if (!item) {
            const name = relPath.split("/").pop() || relPath;
            item = {
                type: "file",
                name,
                rel_path: relPath,
                path: relPath,
                size_bytes: 0,
                mtime_unix: 0
            };
        }

        openPreviewFor(item);
    }

    async function addSelectedImagesToAlbum() {
        const paths = selectedImageRelPaths();

        if (!paths.length) {
            setStatus("Select photos first.");
            return;
        }

        try {
            setBadge("warn", "albums…");
            setStatus("Loading albums…");

            let album = null;

            if (window.PQNAS_PHOTOGALLERY?.albumsPicker?.open) {
                album = await window.PQNAS_PHOTOGALLERY.albumsPicker.open({
                    photoCount: paths.length
                });
            } else {
                throw new Error("albums picker module not loaded");
            }

            if (!album) {
                setBadge("ok", "ready");
                setStatus("Add to album cancelled.");
                return;
            }

            if (!album || !album.album_id) {
                throw new Error("album create/select failed");
            }

            const r = await fetchJson("/api/v4/gallery/albums/add_items", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify({
                    album_id: album.album_id,
                    paths
                })
            });

            setBadge("ok", "ready");
            setStatus(`Added ${r.added || paths.length} photo(s) to album: ${album.name || album.album_id}`);

            if (state.viewMode === "albums") {
                renderGrid();
            }
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Add to album failed: ${String(e && e.message ? e.message : e)}`);
        }
    }

    function resetTreeStats() {
        state.treeStats = {
            basePath: "",
            loaded: false,
            loading: false,
            dirs: 0,
            files: 0,
            fileBytes: 0,
            seq: (state.treeStats?.seq || 0) + 1
        };
    }


    async function ensureTreeStats(force = false) {
        const root = String(state.curPath || "");
        const currentSeq = (state.treeStats?.seq || 0) + 1;

        if (!force &&
            state.treeStats.loaded &&
            !state.treeStats.loading &&
            state.treeStats.basePath === root) {
            return state.treeStats;
        }

        state.treeStats = {
            basePath: root,
            loaded: false,
            loading: true,
            dirs: 0,
            files: 0,
            fileBytes: 0,
            seq: currentSeq
        };

        const serverStats = await fetchServerTreeStats(root, force);

        if (serverStats && state.treeStats && state.treeStats.seq === currentSeq) {
            state.treeStats = {
                basePath: root,
                loaded: true,
                loading: false,
                dirs: Number(serverStats.dirs || 0),
                files: Number(serverStats.files || 0),
                fileBytes: Number(serverStats.fileBytes || 0),
                seq: currentSeq
            };

            return state.treeStats;
        }

        async function walk(path) {
            if (!state.treeStats || state.treeStats.seq !== currentSeq) return;

            const j = await fetchGalleryList(path, { force });
            const items = filterInternalPqnasGalleryItems(Array.isArray(j.items) ? j.items : []);

            for (const it of items) {
                if (it.type === "dir") {
                    state.treeStats.dirs++;
                } else if (it.type === "file") {
                    state.treeStats.files++;
                    state.treeStats.fileBytes += Number(it.size_bytes || 0) || 0;
                }
            }

            for (const it of items) {
                if (it.type === "dir") {
                    await walk(joinPath(path, it.name));
                }
            }
        }

        await walk(root);

        if (state.treeStats && state.treeStats.seq === currentSeq) {
            state.treeStats.loading = false;
            state.treeStats.loaded = true;
        }

        return state.treeStats;
    }

    function visibleItemsSummary() {
        const items = filteredItems();

        let dirs = 0;
        let files = 0;
        let fileBytes = 0;

        for (const it of items) {
            if (it.type === "dir") {
                dirs++;
            } else if (it.type === "file") {
                files++;
                fileBytes += Number(it.size_bytes || 0) || 0;
            }
        }

        return {
            items: items.length,
            dirs,
            files,
            fileBytes
        };
    }

    function selectedItemsSummary() {
        const all = [...state.items, ...state.searchItems];
        const seen = new Set();

        let items = 0;
        let dirs = 0;
        let files = 0;
        let fileBytes = 0;

        for (const it of all) {
            const rel = currentRelPathFor(it);
            if (!rel || seen.has(rel) || !selectedRelPaths.has(rel)) continue;
            seen.add(rel);

            items++;
            if (it.type === "dir") {
                dirs++;
            } else if (it.type === "file") {
                files++;
                fileBytes += Number(it.size_bytes || 0) || 0;
            }
        }

        return { items, dirs, files, fileBytes };
    }

    function refreshFooterStats() {
        if (!footerStats) return;

        const vis = visibleItemsSummary();
        const tree = state.treeStats || {
            loaded: false,
            loading: false,
            dirs: 0,
            files: 0,
            fileBytes: 0
        };

        const parts = [];

        parts.push(`Here: ${vis.items}`);
        parts.push(`Folders: ${vis.dirs}`);
        parts.push(`Files: ${vis.files}`);
        parts.push(`Size: ${fmtSize(vis.fileBytes)}`);

        if (tree.loading) {
            parts.push(`Tree: loading…`);
        } else if (tree.loaded) {
            parts.push(`Tree folders: ${tree.dirs}`);
            parts.push(`Tree files: ${tree.files}`);
            parts.push(`Tree size: ${fmtSize(tree.fileBytes)}`);
        }

        const sel = selectedItemsSummary();
        let html = parts
            .map((p) => `${p}`)
            .join(` <span class="footerStatsDimSep">•</span> `);

        if (sel.items > 0) {
            html += ` <span class="footerStatsDimSep">•</span> <span class="footerStatsSel">Selected: ${sel.items} • ${fmtSize(sel.fileBytes)}</span>`;
        }

        footerStats.innerHTML = html;
    }
    function refreshMetaApplySelectionUi() {
        if (!metaApplySelWrap || !metaApplySelChk || !metaApplySelText) return;

        const selectedImages = selectedImageRelPaths();
        const show =
            !!state.editingPath &&
            selectedImages.length > 1 &&
            selectedImages.includes(state.editingPath);

        metaApplySelWrap.style.display = show ? "" : "none";

        if (!show) {
            metaApplySelChk.checked = false;
            metaApplySelText.textContent = "Apply to selected photos";
            metaApplySelWrap.style.background = "";
            metaApplySelWrap.style.border = "";
            metaApplySelWrap.style.borderRadius = "";
            metaApplySelWrap.style.padding = "";
            return;
        }

        metaApplySelText.textContent =
            `Apply to ${selectedImages.length} selected photo${selectedImages.length === 1 ? "" : "s"}`;

        if (metaApplySelChk.checked) {
            metaApplySelWrap.style.background = "rgba(255, 215, 0, 0.18)";
            metaApplySelWrap.style.border = "1px solid rgba(255, 215, 0, 0.45)";
        } else {
            metaApplySelWrap.style.background = "rgba(255, 215, 0, 0.10)";
            metaApplySelWrap.style.border = "1px solid rgba(255, 215, 0, 0.28)";
        }

        metaApplySelWrap.style.borderRadius = "10px";
        metaApplySelWrap.style.padding = "10px 12px";
    }
    function getZipFilenameFromResponse(r, fallback = "gallery-selection.zip") {
        const cd = r.headers.get("Content-Disposition") || "";

        let m = cd.match(/filename\*=UTF-8''([^;]+)/i);
        if (m && m[1]) {
            try { return decodeURIComponent(m[1]); } catch (_) {}
        }

        m = cd.match(/filename="?([^"]+)"?/i);
        if (m && m[1]) return m[1];

        return fallback;
    }
    function triggerBlobDownload(blob, filename) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename || "download";
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1500);
    }

    function triggerDirectFileDownload(relPath, filename) {
        const a = document.createElement("a");
        a.href = fileGetUrl(relPath);
        a.download = filename || "";
        document.body.appendChild(a);
        a.click();
        a.remove();
    }

    async function fetchSelectionArchive(url, body, fallbackName, busyText, doneText) {
        setBadge("warn", "zip…");
        setStatus(busyText);

        try {
            const r = await fetch(url, {
                method: "POST",
                credentials: "include",
                cache: "no-store",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body)
            });

            if (!r.ok) {
                const t = await r.text().catch(() => "");
                throw new Error(`HTTP ${r.status}${t ? " — " + t : ""}`);
            }

            const blob = await r.blob();
            triggerBlobDownload(blob, getZipFilenameFromResponse(r, fallbackName));

            setBadge("ok", "ready");
            setStatus(doneText);
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Download failed: ${String(e && e.message ? e.message : e)}`);
        }
    }

    function selectedBasePath() {
        return state.curPath || "";
    }

    async function exportSelectionZip() {
        const paths = selectedRelPathsList();
        if (!paths.length) {
            setStatus(pgT("photogallery.nothing_selected", null, "Nothing selected."));
            return;
        }

        await fetchSelectionArchive(
            "/api/v4/gallery/export_sel_zip",
            { paths, base: selectedBasePath() },
            "gallery-export.zip",
            `Preparing export (${paths.length} item${paths.length === 1 ? "" : "s"})…`,
            `Export ready (${paths.length} item${paths.length === 1 ? "" : "s"}).`
        );
    }

    function downloadSingleImage(item) {
        const rel = currentRelPathFor(item);
        triggerDirectFileDownload(rel, item.name || "image");
        setBadge("ok", "ready");
        setStatus(`Download started: ${item.name || rel}`);
    }

    async function downloadSingleFolderZip(item) {
        const rel = currentRelPathFor(item);
        await fetchSelectionArchive(
            "/api/v4/files/zip_sel",
            { paths: [rel], base: parentPath(rel) || "" },
            `${item.name || "folder"}.zip`,
            `Preparing zip for ${item.name || rel}…`,
            `Download ready: ${item.name || rel}`
        );
    }

    async function exportSingleItemZip(item) {
        const rel = currentRelPathFor(item);
        await fetchSelectionArchive(
            "/api/v4/gallery/export_sel_zip",
            { paths: [rel], base: parentPath(rel) || "" },
            "gallery-export.zip",
            `Preparing export for ${item.name || rel}…`,
            `Export ready: ${item.name || rel}`
        );
    }
    async function downloadSelectionZip() {
        const paths = selectedRelPathsList();
        if (!paths.length) {
            setStatus(pgT("photogallery.nothing_selected", null, "Nothing selected."));
            return;
        }

        await fetchSelectionArchive(
            "/api/v4/files/zip_sel",
            { paths, base: selectedBasePath() },
            "selection.zip",
            `Preparing zip (${paths.length} item${paths.length === 1 ? "" : "s"})…`,
            `Download ready (${paths.length} item${paths.length === 1 ? "" : "s"}).`
        );
    }

    async function deleteSelection() {
        const paths = selectedRelPathsList();
        if (!paths.length) {
            setStatus(pgT("photogallery.nothing_selected", null, "Nothing selected."));
            return;
        }

        const ok = await pgConfirmModal({
            title: pgT("photogallery.trash.confirm_selected_title", { count: paths.length }, "Move {count} selected item(s) to trash?"),
            note: pgT("photogallery.trash.restore_them_later_note", null, "You can restore them later from Trash."),
            confirmText: pgT("photogallery.trash.move_to_trash", null, "Move to trash"),
            cancelText: pgT("common.cancel", null, "Cancel"),
            danger: true,
        });
        if (!ok) return;

        setBadge("warn", "working…");
        setStatus(pgT("photogallery.trash.moving_selected", { count: paths.length }, "Moving {count} item(s) to trash…"));

        let done = 0;
        const failed = [];

        for (const rel of paths) {
            try {
                const r = await fetch(
                    `/api/v4/files/delete?path=${encodeURIComponent(rel)}`,
                    {
                        method: "POST",
                        credentials: "include",
                        cache: "no-store"
                    }
                );

                const j = await r.json().catch(() => null);
                if (!r.ok || !j || !j.ok) {
                    const msg = j && (j.message || j.error)
                        ? `${j.error || ""} ${j.message || ""}`.trim()
                        : `HTTP ${r.status}`;
                    throw new Error(msg || `HTTP ${r.status}`);
                }

                done++;

                if (state.previewPath === rel) closePreviewModal();
                if (state.editingPath === rel) closeMetaModal();
            } catch (e) {
                failed.push(`${rel}: ${String(e && e.message ? e.message : e)}`);
            }
        }

        clearSelection();
        clearFolderListCache();
        resetTreeStats();
        invalidateSearchCache();
        await load(true);

        if (failed.length) {
            setBadge("warn", "partial");
            setStatus(pgT("photogallery.trash.partial_result", { done, total: paths.length, failed: failed.length }, "Moved to trash {done}/{total}. Failed: {failed}"));
            console.warn("Photo Gallery deleteSelection failures:", failed);
        } else {
            setBadge("ok", "ready");
            setStatus(pgT("photogallery.trash.moved_selected", { count: done }, "Moved to trash {count} item(s)."));
        }
    }
    const marquee = document.createElement("div");
    marquee.style.position = "absolute";
    marquee.style.border = "1px solid rgba(var(--fg-rgb),0.45)";
    marquee.style.background = "rgba(var(--fg-rgb),0.12)";
    marquee.style.borderRadius = "10px";
    marquee.style.pointerEvents = "none";
    marquee.style.display = "none";
    marquee.style.zIndex = "9999";
    document.body.appendChild(marquee);

    let marqueeOn = false;
    let marqueeStartX = 0;
    let marqueeStartY = 0;
    let marqueeBaseSelection = null;

    function tileRects() {
        if (!gridEl) return [];
        const out = [];
        for (const tileEl of gridEl.querySelectorAll(".tile")) {
            out.push({
                relPath: String(tileEl.dataset.relPath || ""),
                rect: tileEl.getBoundingClientRect()
            });
        }
        return out;
    }

    function rectIntersects(a, b) {
        return !(a.right < b.left || a.left > b.right || a.bottom < b.top || a.top > b.bottom);
    }

    function endMarquee() {
        if (!marqueeOn) return;
        marqueeOn = false;
        marquee.style.display = "none";
        marqueeBaseSelection = null;
    }

    gridWrap?.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        if (e.target && e.target.closest && e.target.closest(".tile")) return;
        if (ctxMenu && ctxMenu.classList.contains("show")) return;

        marqueeOn = true;
        marqueeStartX = e.clientX;
        marqueeStartY = e.clientY;
        marqueeBaseSelection = (e.ctrlKey || e.metaKey) ? new Set(selectedRelPaths) : null;

        if (!marqueeBaseSelection) clearSelection();

        marquee.style.left = `${marqueeStartX}px`;
        marquee.style.top = `${marqueeStartY}px`;
        marquee.style.width = "0px";
        marquee.style.height = "0px";
        marquee.style.display = "block";

        try { gridWrap.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
    });

    gridWrap?.addEventListener("pointermove", (e) => {
        if (!marqueeOn) return;

        const x = e.clientX;
        const y = e.clientY;

        const left = Math.min(marqueeStartX, x);
        const top = Math.min(marqueeStartY, y);
        const right = Math.max(marqueeStartX, x);
        const bottom = Math.max(marqueeStartY, y);

        marquee.style.left = `${left}px`;
        marquee.style.top = `${top}px`;
        marquee.style.width = `${right - left}px`;
        marquee.style.height = `${bottom - top}px`;

        const selRect = { left, top, right, bottom };
        const rects = tileRects();
        const next = marqueeBaseSelection ? new Set(marqueeBaseSelection) : new Set();

        for (const t of rects) {
            if (t.relPath && rectIntersects(selRect, t.rect)) {
                next.add(t.relPath);
            }
        }

        selectedRelPaths = next;
        applySelectionToDom();
    });

    gridWrap?.addEventListener("pointerup", endMarquee);

    panelEl?.addEventListener("contextmenu", (e) => {
        const target = e.target;

        if (!target || !(target instanceof Element)) return;

        // Let tile-specific handlers keep control.
        if (target.closest(".tile")) return;

        // Do not hijack native menu inside editable controls.
        if (target.closest("input, textarea, select")) return;

        // Do not interfere with modals.
        if (target.closest(".modal.show")) return;

        // Albums have their own collection context menu in albums_view.js.
        // Do not show the normal gallery upload/new-folder context menu there.
        if (target.closest("#albumsWrap")) {
            return;
        }

        if (state.viewMode === "albums") {
            e.preventDefault();
            e.stopPropagation();
            closeContextMenu();
            return;
        }
        e.preventDefault();
        e.stopPropagation();

        if (selectedRelPaths.size > 0) {
            openSelectionContextMenu(e.clientX, e.clientY);
        } else {
            openBackgroundContextMenu(e.clientX, e.clientY);
        }
    }, true);

    gridWrap?.addEventListener("pointercancel", endMarquee);
    function renderBreadcrumb() {
        if (!pathLine) return;
        pathLine.replaceChildren();

        const root = document.createElement("span");
        root.className = "crumb";
        root.textContent = "/";
        root.title = "Go to root";
        root.addEventListener("click", () => {
            setCurrentPath("", "breadcrumb-root");
            clearSelection();
            load();
        });
        pathLine.appendChild(root);

        if (!state.curPath) {
            root.classList.add("active");
            return;
        }

        const parts = String(state.curPath).split("/").filter(Boolean);
        let acc = "";

        for (let i = 0; i < parts.length; i++) {
            const sep = document.createElement("span");
            sep.className = "crumbSep";
            sep.textContent = "›";
            pathLine.appendChild(sep);

            const name = parts[i];
            acc = acc ? `${acc}/${name}` : name;

            const crumb = document.createElement("span");
            crumb.className = "crumb";
            if (i === parts.length - 1) crumb.classList.add("active");
            crumb.title = "/" + acc;

            const txt = document.createElement("span");
            txt.className = "crumbText";
            txt.textContent = name;
            crumb.appendChild(txt);

            if (i !== parts.length - 1) {
                const target = acc;
                crumb.addEventListener("click", () => {
                    setCurrentPath(target, "breadcrumb-click");
                    clearSelection();
                    load();
                });
            }

            pathLine.appendChild(crumb);
        }
    }

    function sortItems(items) {
        return items.slice().sort((a, b) => {
            if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
            return String(a.name || "").localeCompare(String(b.name || ""));
        });
    }

    function activeExternalSearchFilters() {
        return externalSearchFilters.filter((provider) => {
            try {
                return provider && typeof provider.isActive === "function" && provider.isActive();
            } catch (_) {
                return false;
            }
        });
    }

    function isExternalSearchActive() {
        return activeExternalSearchFilters().length > 0;
    }

    function externalSearchSummaryText() {
        const parts = [];
        for (const provider of activeExternalSearchFilters()) {
            try {
                if (typeof provider.summary === "function") {
                    const s = String(provider.summary() || "").trim();
                    if (s) parts.push(s);
                }
            } catch (_) {}
        }
        return parts.join(" • ");
    }

    function itemMatchesExternalSearchFilters(it) {
        for (const provider of activeExternalSearchFilters()) {
            try {
                if (typeof provider.matches === "function" && !provider.matches(it)) {
                    return false;
                }
            } catch (_) {
                return false;
            }
        }
        return true;
    }

    function isSearchMode() {
        const hasText = !!String(state.filter || "").trim();
        const rf = Number(state.ratingFilter);
        const hasRating = Number.isFinite(rf) && rf >= 0;
        return hasText || hasRating || isExternalSearchActive();
    }

    function invalidateSearchCache() {
        searchSeq++;
        state.searchItems = [];
        state.searchBasePath = "";
        state.searchLoaded = false;
        state.searchLoading = false;
    }

    function groupPathForItem(item) {
        return parentPath(currentRelPathFor(item));
    }

    function sortSearchItems(items) {
        return items.slice().sort((a, b) => {
            const ap = groupPathForItem(a);
            const bp = groupPathForItem(b);
            const byPath = String(ap).localeCompare(String(bp));
            if (byPath) return byPath;
            return String(a.name || "").localeCompare(String(b.name || ""));
        });
    }

    async function ensureRecursiveSearchItems(force = false) {
        const root = String(state.curPath || "");

        if (!force && state.searchLoaded && state.searchBasePath === root) {
            state.searchLoading = false;
            return state.searchItems;
        }

        const mySeq = ++searchSeq;
        state.searchLoading = true;
        state.searchLoaded = false;
        state.searchBasePath = root;
        state.searchItems = [];

        setStatus(`Loading photo index under /${root || ""} …`);

        const serverItems = await fetchServerRecursiveSearchItems(root, force);

        if (mySeq !== searchSeq) throw new Error("__stale_search__");

        if (serverItems) {
            state.searchItems = serverItems;
            state.searchLoaded = true;
            state.searchLoading = false;
            return state.searchItems;
        }

        const out = [];
        let scannedFolders = 0;

        async function walk(path) {
            if (mySeq !== searchSeq) throw new Error("__stale_search__");

            scannedFolders++;
            setStatus(`Searching /${path || ""} … folders: ${scannedFolders}, photos: ${out.length}`);

            const j = await fetchGalleryList(path, { force });
            const items = sortItems(filterInternalPqnasGalleryItems(Array.isArray(j.items) ? j.items : []));

            for (const it of items) {
                const rel = joinPath(path, it.name);
                if (it.type === "file") {
                    out.push({
                        ...it,
                        rel_path: rel,
                        base_path: path
                    });
                }
            }

            for (const it of items) {
                if (it.type === "dir") {
                    await walk(joinPath(path, it.name));
                }
            }
        }

        try {
            await walk(root);

            if (mySeq !== searchSeq) throw new Error("__stale_search__");

            state.searchItems = out;
            state.searchLoaded = true;
            return out;
        } finally {
            if (mySeq === searchSeq) {
                state.searchLoading = false;
            }
        }
    }

    function makeSearchGroupHeader(folderPath, count, first) {
        const head = document.createElement("div");
        head.className = "searchGroupHead";
        head.style.gridColumn = "1 / -1";
        head.style.display = "flex";
        head.style.justifyContent = "space-between";
        head.style.alignItems = "baseline";
        head.style.gap = "12px";
        head.style.padding = first ? "0 2px 10px" : "14px 2px 10px";
        head.style.margin = first ? "0 0 4px" : "10px 0 4px";
        head.style.borderTop = first ? "none" : "1px solid rgba(var(--fg-rgb),0.16)";

        const left = document.createElement("div");
        left.style.fontWeight = "600";
        left.style.opacity = "0.95";
        left.textContent = "/" + (folderPath || "");

        const right = document.createElement("div");
        right.style.fontSize = "12px";
        right.style.opacity = "0.72";
        right.textContent = `${count} photo${count === 1 ? "" : "s"}`;

        head.appendChild(left);
        head.appendChild(right);
        return head;
    }

    function updateViewStatus() {
        const rf = Number(state.ratingFilter);
        const ratingTxt =
            rf < 0 ? "" :
                (rf === 0 ? " • unrated only" : ` • ${rf}★ only`);
        const extraTxt = externalSearchSummaryText();
        const textTxt =
            `${state.filter ? ` • filter: ${state.filter}` : ""}${extraTxt ? ` • ${extraTxt}` : ""}`;

        const items = filteredItems();
        if (state.viewMode === "map") {
            const gpsCount = mapItems().length;
            const textTxt =
                state.filter ? ` • filter: ${state.filter}` : "";
            const rf = Number(state.ratingFilter);
            const ratingTxt =
                rf < 0 ? "" :
                    (rf === 0 ? " • unrated only" : ` • ${rf}★ only`);

            setStatus(`Map: ${gpsCount} GPS photo${gpsCount === 1 ? "" : "s"} under /${state.curPath || ""}${ratingTxt}${textTxt}`);
            return;
        }
        if (isSearchMode()) {
            const pathCount = new Set(items.map((it) => groupPathForItem(it))).size;
            const scopeTxt = ` under /${state.curPath || ""}`;
            setStatus(
                `Found ${items.length} photo${items.length === 1 ? "" : "s"} in ${pathCount} path${pathCount === 1 ? "" : "s"}${scopeTxt}${ratingTxt}${textTxt}`
            );
            return;
        }

        setStatus(`Items: ${items.length}${ratingTxt}${textTxt}`);
    }

    async function refreshVisibleView(forceSearch = false) {
        try {
            if (isSearchMode()) {
                const needSearch =
                    forceSearch ||
                    !state.searchLoaded ||
                    state.searchBasePath !== state.curPath;

                if (needSearch) {
                    state.searchLoading = true;
                    renderGrid();
                    setBadge("warn", "search…");
                    setStatus("Searching subfolders…");
                    await ensureRecursiveSearchItems(forceSearch);
                }
            } else {
                state.searchLoading = false;
            }

            renderGrid();
            window.dispatchEvent(new CustomEvent("photogallery:view-updated"));
            setBadge("ok", "ready");
            updateViewStatus();
        } catch (e) {
            const msg = String(e && e.message ? e.message : e);
            if (msg === "__stale_search__") return;

            state.searchLoading = false;
            renderGrid();
            setBadge("err", "error");
            setStatus(`Search failed: ${msg}`);
        }
    }


    function exifSearchText(it) {
        const exif = it && it.exif && typeof it.exif === "object" ? it.exif : {};
        const parts = [];
        const add = (v) => {
            const x = String(v == null ? "" : v).trim();
            if (x) parts.push(x);
        };

        add(exif.make);
        add(exif.model);
        add(exif.lens_model);
        add([exif.make, exif.model].map(v => String(v || "").trim()).filter(Boolean).join(" "));

        const iso = Number(exif.iso || 0);
        if (Number.isFinite(iso) && iso > 0) {
            add(`ISO ${iso}`);
            add(`iso ${iso}`);
            add(String(iso));
        }

        const fnum = Number(exif.f_number || 0);
        if (Number.isFinite(fnum) && fnum > 0) {
            add(`f/${fnum}`);
            add(`aperture ${fnum}`);
        }

        const focal = Number(exif.focal_length || 0);
        if (Number.isFinite(focal) && focal > 0) {
            add(`${focal}mm`);
            add(`focal ${focal}`);
        }

        add(it && it.capture_time_text);

        if (it && it.has_gps) {
            add("gps");
            add("has gps");
            add("geotag");
            add("location");
        }

        return parts.join(" ");
    }

    function exifPreviewText(it) {
        const exif = it && it.exif && typeof it.exif === "object" ? it.exif : {};
        const bits = [];

        const camera = [exif.make, exif.model]
            .map(v => String(v || "").trim())
            .filter(Boolean)
            .join(" ");

        if (camera) bits.push(camera);

        const iso = Number(exif.iso || 0);
        if (Number.isFinite(iso) && iso > 0) bits.push(`ISO ${iso}`);

        const lens = String(exif.lens_model || "").trim();
        if (lens) bits.push(lens);

        return bits.join(" • ");
    }

    function filteredItems() {
        const q = String(state.filter || "").trim().toLowerCase();
        const rating = Number(state.ratingFilter);

        const baseItems = isSearchMode()
            ? sortSearchItems(state.searchItems)
            : sortItems(state.items);

        return baseItems.filter((it) => {
            if (Number.isFinite(rating) && rating >= 0) {
                if (it.type !== "file") return false;
                const stars = Number(it.rating || 0) || 0;
                if (stars !== rating) return false;
            }

            if (!itemMatchesExternalSearchFilters(it)) return false;

            if (!q) return true;

            if (it.type !== "file") return false;

            const hay = [
                it.name || "",
                groupPathForItem(it),
                Array.isArray(it.keywords) ? it.keywords.join(" ") : (it.tags_text || ""),
                it.description || it.notes_text || "",
                exifSearchText(it)
            ].join(" ").toLowerCase();

            return hay.includes(q);
        });
    }
    function displayItems() {
        const items = filteredItems();

        if (!window.PQNAS_PHOTOGALLERY?.bursts?.buildDisplayItems) {
            return items.map((item) => ({ kind: "item", item }));
        }

        return window.PQNAS_PHOTOGALLERY.bursts.buildDisplayItems(items);
    }
    function normalizeGalleryMeta(meta) {
        const imageRating =
            meta && meta.imageRating != null
                ? Number(meta.imageRating || 0) || 0
                : Number(meta && meta.rating || 0) || 0;

        const keywords = Array.isArray(meta && meta.keywords)
            ? meta.keywords.map(v => String(v || "").trim()).filter(Boolean)
            : String(meta && meta.tags_text || "")
                .split(",")
                .map(v => v.trim())
                .filter(Boolean);

        const description =
            meta && meta.description && typeof meta.description === "object"
                ? String(meta.description["x-default"] || "")
                : String(meta && meta.notes_text || "");

        return {
            imageRating,
            keywords,
            description
        };
    }
    function applyMetaToItem(it, meta) {
        if (!it) return;

        const { imageRating, keywords, description } = normalizeGalleryMeta(meta);

        it.rating = imageRating;
        it.keywords = keywords.slice();
        it.description = description;

        // Keep old compatibility fields alive for now.
        it.tags_text = keywords.join(", ");
        it.notes_text = description;

        if (meta && meta.size_bytes != null) it.size_bytes = Number(meta.size_bytes || 0);
        if (meta && meta.mtime_epoch != null) it.mtime_unix = Number(meta.mtime_epoch || 0);
    }

    function applyMetaToCaches(rel, meta) {
        for (const it of state.items) {
            if (currentRelPathFor(it) === rel) applyMetaToItem(it, meta);
        }
        for (const it of state.searchItems) {
            if (currentRelPathFor(it) === rel) applyMetaToItem(it, meta);
        }
    }

    function filteredImageItems() {
        return filteredItems().filter((it) => it.type === "file");
    }
    function isTypingTarget(target) {
        if (!target || !(target instanceof Element)) return false;
        return !!target.closest("input, textarea, select, button, [contenteditable='true']");
    }

    function getRenderedTiles() {
        return gridEl ? Array.from(gridEl.querySelectorAll(".tile")) : [];
    }

    function findTileByRelPath(relPath) {
        return getRenderedTiles().find((tile) => tile.dataset.relPath === relPath) || null;
    }

    function updateTileSelection() {
        for (const tile of getRenderedTiles()) {
            const active = !!state.activeTilePath && tile.dataset.relPath === state.activeTilePath;
            tile.classList.toggle("kbdActive", active);
            tile.tabIndex = active ? 0 : -1;
            tile.setAttribute("aria-selected", active ? "true" : "false");
        }
    }

    function setActiveTileRelPath(relPath, opts = {}) {
        const scroll = opts.scroll !== false;
        const focus = opts.focus === true;

        state.activeTilePath = String(relPath || "");

        const tile = findTileByRelPath(state.activeTilePath);
        updateTileSelection();

        if (!tile) return null;

        if (scroll) {
            tile.scrollIntoView({
                block: "nearest",
                inline: "nearest"
            });
        }

        if (focus) {
            try {
                tile.focus({ preventScroll: true });
            } catch (_) {
                try { tile.focus(); } catch (_) {}
            }
        }

        return tile;
    }

    function ensureActiveTile() {
        const tiles = getRenderedTiles();
        if (!tiles.length) {
            state.activeTilePath = "";
            return null;
        }

        const existing = findTileByRelPath(state.activeTilePath);
        if (existing) {
            updateTileSelection();
            return existing;
        }

        return setActiveTileRelPath(tiles[0].dataset.relPath || "", {
            scroll: false,
            focus: false
        });
    }

    function moveLinear(delta) {
        const tiles = getRenderedTiles();
        if (!tiles.length) return;

        const current = ensureActiveTile();
        const idx = Math.max(0, tiles.indexOf(current));
        const nextIdx = clamp(idx + delta, 0, tiles.length - 1);
        const nextRel = tiles[nextIdx].dataset.relPath || "";

        setSingleSelection(nextRel, {
            scroll: true,
            focus: true
        });
    }

    function buildTileRows() {
        const tiles = getRenderedTiles().map((tile) => {
            const rect = tile.getBoundingClientRect();
            return {
                tile,
                relPath: tile.dataset.relPath || "",
                left: rect.left,
                top: rect.top,
                width: rect.width,
                height: rect.height,
                centerX: rect.left + rect.width / 2
            };
        });

        tiles.sort((a, b) => {
            const dy = a.top - b.top;
            if (Math.abs(dy) > 24) return dy;
            return a.left - b.left;
        });

        const rows = [];
        for (const entry of tiles) {
            const lastRow = rows[rows.length - 1];
            if (!lastRow || Math.abs(entry.top - lastRow[0].top) > 24) {
                rows.push([entry]);
            } else {
                lastRow.push(entry);
            }
        }

        return rows;
    }

    function getActiveRowPos(rows) {
        for (let r = 0; r < rows.length; r++) {
            for (let c = 0; c < rows[r].length; c++) {
                if (rows[r][c].relPath === state.activeTilePath) {
                    return { row: r, col: c, entry: rows[r][c] };
                }
            }
        }

        if (rows.length && rows[0].length) {
            return { row: 0, col: 0, entry: rows[0][0] };
        }

        return null;
    }

    function closestIndexByX(row, targetX) {
        let bestIdx = 0;
        let bestDist = Infinity;

        for (let i = 0; i < row.length; i++) {
            const d = Math.abs(row[i].centerX - targetX);
            if (d < bestDist) {
                bestDist = d;
                bestIdx = i;
            }
        }

        return bestIdx;
    }

    function moveVertical(deltaRows) {
        const rows = buildTileRows();
        const pos = getActiveRowPos(rows);
        if (!pos) return;

        const targetRow = clamp(pos.row + deltaRows, 0, rows.length - 1);
        if (targetRow === pos.row) return;

        const targetCol = closestIndexByX(rows[targetRow], pos.entry.centerX);
        const nextRel = rows[targetRow][targetCol].relPath;

        setSingleSelection(nextRel, {
            scroll: true,
            focus: true
        });
    }

    function moveByPage(deltaPages) {
        const rows = buildTileRows();
        const pos = getActiveRowPos(rows);
        if (!pos) return;

        const viewportH = gridEl ? gridEl.clientHeight : window.innerHeight;
        const rowHeight = Math.max(1, pos.entry.height);
        const stepRows = Math.max(1, Math.floor(viewportH / rowHeight) - 1);

        const targetRow = clamp(pos.row + (deltaPages * stepRows), 0, rows.length - 1);
        const targetCol = closestIndexByX(rows[targetRow], pos.entry.centerX);
        const nextRel = rows[targetRow][targetCol].relPath;

        setSingleSelection(nextRel, {
            scroll: true,
            focus: true
        });
    }

    function activateSelectedTile() {
        const tile = ensureActiveTile();
        if (!tile) return;
        tile.click();
    }
    function openSelectedTileMetadata() {
        const tile = ensureActiveTile();
        if (!tile) return;

        if ((tile.dataset.itemType || "") !== "file") {
            return;
        }

        const relPath = tile.dataset.relPath || "";
        if (!relPath) return;

        openMetaFor(relPath);
    }
    function currentPreviewIndex() {
        const items = filteredImageItems();
        const idx = items.findIndex((it) => currentRelPathFor(it) === state.previewPath);
        return { items, idx };
    }

    function updatePreviewNav() {
        const { items, idx } = currentPreviewIndex();
        const hasMany = items.length > 1;
        if (previewPrevBtn) previewPrevBtn.disabled = !hasMany || idx < 0;
        if (previewNextBtn) previewNextBtn.disabled = !hasMany || idx < 0;
        if (previewMetaBtn) previewMetaBtn.disabled = idx < 0;
    }
    function clampPreviewZoom(z) {
        return clamp(Number(z || 1), 0.05, 8);
    }

    function computeFitZoom() {
        if (!previewImg || !previewBody || !previewImg.naturalWidth || !previewImg.naturalHeight) {
            return 1;
        }

        const fitX = previewBody.clientWidth / previewImg.naturalWidth;
        const fitY = previewBody.clientHeight / previewImg.naturalHeight;
        return Math.min(1, fitX, fitY);
    }

    function currentPreviewZoom() {
        return state.previewMode === "fit"
            ? computeFitZoom()
            : clampPreviewZoom(state.previewZoom || 1);
    }

    function setPreviewScrollableMode(on) {
        if (!previewBody) return;

        previewBody.style.display = on ? "block" : "flex";
        previewBody.style.alignItems = on ? "flex-start" : "center";
        previewBody.style.justifyContent = on ? "flex-start" : "center";
    }

    function updatePreviewInfoText() {
        if (!previewInfo || !previewImg || !previewImg.naturalWidth || !previewImg.naturalHeight) return;

        const { items, idx } = currentPreviewIndex();
        const pos = (idx >= 0 && items.length > 1) ? ` • ${idx + 1} / ${items.length}` : "";
        const pct = Math.round(currentPreviewZoom() * 100);

        previewInfo.textContent = `${previewImg.naturalWidth} × ${previewImg.naturalHeight} • ${pct}%${pos}`;
    }

    function isPreviewFullscreen() {
        return !!previewModal && document.fullscreenElement === previewModal;
    }

    async function enterPreviewFullscreen() {
        if (!previewModal) return;

        previewModal.classList.add("previewFullscreen");

        try {
            await previewModal.requestFullscreen();
        } catch (_) {
            previewModal.classList.remove("previewFullscreen");
        }
    }

    async function exitPreviewFullscreen() {
        if (!isPreviewFullscreen()) return;

        try {
            await document.exitFullscreen();
        } catch (_) {}
    }

    async function togglePreviewFullscreen() {
        if (isPreviewFullscreen()) {
            await exitPreviewFullscreen();
        } else {
            await enterPreviewFullscreen();
        }
    }

    function syncPreviewFullscreenUi() {
        const on = isPreviewFullscreen();

        if (!on && previewModal) {
            previewModal.classList.remove("previewFullscreen");
        }

        if (previewFullscreenBtn) {
            const labelKey = on ? "photogallery.windowed" : "photogallery.fullscreen";
            const titleKey = on ? "photogallery.exit_fullscreen" : "photogallery.enter_fullscreen";
            const labelFallback = on ? "Poistu koko näytöstä" : "Koko näyttö";
            const titleFallback = on ? "Poistu koko näytöstä" : "Siirry koko näytön tilaan";

            previewFullscreenBtn.setAttribute("data-i18n", labelKey);
            previewFullscreenBtn.setAttribute("data-i18n-title", titleKey);
            previewFullscreenBtn.textContent = pgT(labelKey, null, labelFallback);
            previewFullscreenBtn.title = pgT(titleKey, null, titleFallback);
        }
    }

    function isPreviewPannable() {
        if (!previewBody || !previewImg || !previewImg.naturalWidth || !previewImg.naturalHeight) {
            return false;
        }

        return currentPreviewZoom() > computeFitZoom() + 0.01;
    }

    function updatePreviewPanCursor() {
        if (!previewBody) return;

        if (previewPanState.active) {
            previewBody.style.cursor = "grabbing";
        } else if (isPreviewPannable()) {
            previewBody.style.cursor = "grab";
        } else {
            previewBody.style.cursor = "";
        }
    }

    function applyPreviewZoom(nextZoom, opts = {}) {
        if (!previewImg || !previewBody || !previewImg.naturalWidth || !previewImg.naturalHeight) return;

        const fitZoom = computeFitZoom();
        const zoom = clampPreviewZoom(nextZoom);

        if (opts.snapToFit !== false && Math.abs(zoom - fitZoom) < 0.02) {
            applyPreviewFitMode();
            return;
        }

        const bodyRect = previewBody.getBoundingClientRect();
        const oldRect = previewImg.getBoundingClientRect();
        const oldWidth = oldRect.width || (previewImg.naturalWidth * currentPreviewZoom());
        const oldHeight = oldRect.height || (previewImg.naturalHeight * currentPreviewZoom());

        const clientX = Number.isFinite(opts.clientX)
            ? opts.clientX
            : (bodyRect.left + bodyRect.width / 2);

        const clientY = Number.isFinite(opts.clientY)
            ? opts.clientY
            : (bodyRect.top + bodyRect.height / 2);

        const offsetX = previewBody.scrollLeft + (clientX - bodyRect.left);
        const offsetY = previewBody.scrollTop + (clientY - bodyRect.top);

        const relX = oldWidth > 0 ? (offsetX / oldWidth) : 0.5;
        const relY = oldHeight > 0 ? (offsetY / oldHeight) : 0.5;

        state.previewMode = "zoom";
        state.previewZoom = zoom;

        setPreviewScrollableMode(true);

        previewImg.style.maxWidth = "none";
        previewImg.style.maxHeight = "none";
        previewImg.style.width = `${Math.max(1, Math.round(previewImg.naturalWidth * zoom))}px`;
        previewImg.style.height = `${Math.max(1, Math.round(previewImg.naturalHeight * zoom))}px`;

        requestAnimationFrame(() => {
            const newRect = previewImg.getBoundingClientRect();
            const newWidth = newRect.width || (previewImg.naturalWidth * zoom);
            const newHeight = newRect.height || (previewImg.naturalHeight * zoom);

            previewBody.scrollLeft = Math.max(0, relX * newWidth - (clientX - bodyRect.left));
            previewBody.scrollTop = Math.max(0, relY * newHeight - (clientY - bodyRect.top));

            updatePreviewInfoText();
            updatePreviewPanCursor();
        });
    }
    function applyPreviewFitMode() {
        if (!previewImg) return;

        state.previewMode = "fit";
        state.previewZoom = computeFitZoom();

        setPreviewScrollableMode(false);

        if (previewBody) {
            previewBody.scrollLeft = 0;
            previewBody.scrollTop = 0;
        }

        previewImg.style.width = "auto";
        previewImg.style.height = "auto";
        previewImg.style.maxWidth = "100%";
        previewImg.style.maxHeight = "100%";

        updatePreviewInfoText();
        updatePreviewPanCursor();
    }

    function applyPreviewActualMode() {
        applyPreviewZoom(1, { snapToFit: false });
    }

    function openPreviewByIndex(nextIdx) {
        const { items } = currentPreviewIndex();
        if (!items.length) return;
        const len = items.length;
        const idx = ((nextIdx % len) + len) % len;
        openPreviewFor(items[idx]);
    }

    function openPreviewFor(item) {
        if (!item || item.type !== "file") return;

        const rel = currentRelPathFor(item);
        state.previewPath = rel;

        if (previewPath) previewPath.textContent = "/" + rel;
        if (previewInfo) previewInfo.textContent = "Loading…";

        if (previewImg) {
            previewImg.alt = item.name || "image";

            previewImg.onload = () => {
                applyPreviewFitMode();
                updatePreviewNav();
                syncPreviewFullscreenUi();
            };

            previewImg.onerror = () => {
                if (previewInfo) previewInfo.textContent = "Failed to load preview";
            };
            previewImg.draggable = false;
            previewImg.src = fileGetUrl(rel);
        }

        const wasAlreadyOpen = !!(previewModal && previewModal.classList.contains("show"));

        if (!wasAlreadyOpen) {
            placePreviewCentered();
        }

        openPreviewModal();
        updatePreviewNav();

        window.dispatchEvent(new CustomEvent("photogallery:preview-open", {
            detail: { relPath: rel }
        }));
    }

    function openPreviewModal() {
        if (!previewModal) return;
        previewModal.classList.add("show");
        previewModal.setAttribute("aria-hidden", "false");
    }

    function closePreviewModal() {
        if (!previewModal) return;

        if (isPreviewFullscreen()) {
            document.exitFullscreen().catch(() => {});
        }

        previewModal.classList.remove("previewFullscreen");
        const oldRel = state.previewPath;

        previewModal.classList.remove("show");
        previewModal.setAttribute("aria-hidden", "true");
        state.previewPath = "";

        state.previewMode = "fit";
        state.previewZoom = 1;

        if (previewBody) {
            previewBody.scrollLeft = 0;
            previewBody.scrollTop = 0;
        }

        if (previewImg) {
            previewImg.removeAttribute("src");
            previewImg.alt = "";
        }

        previewPanState.active = false;
        previewPanState.moved = false;
        updatePreviewPanCursor();

        window.dispatchEvent(new CustomEvent("photogallery:preview-close", {
            detail: { relPath: oldRel }
        }));
    }

    function placePreviewCentered() {
        if (!previewCard) return;
        previewCard.style.transform = "translateX(-50%)";
        previewCard.style.left = "50%";
        previewCard.style.top = "80px";
    }


    function clampPreviewIntoViewport() {
        if (!previewCard) return;

        const rect = previewCard.getBoundingClientRect();
        const pad = 8;

        let left = rect.left;
        let top = rect.top;

        const maxLeft = Math.max(pad, window.innerWidth - rect.width - pad);
        const maxTop = Math.max(pad, window.innerHeight - rect.height - pad);

        left = clamp(left, pad, maxLeft);
        top = clamp(top, pad, maxTop);

        previewCard.style.transform = "none";
        previewCard.style.left = `${left}px`;
        previewCard.style.top = `${top}px`;
    }

    let previewResizeRaf = 0;

    function syncPreviewAfterCardResize() {
        if (!previewModal || !previewModal.classList.contains("show")) return;

        if (previewResizeRaf) {
            window.cancelAnimationFrame(previewResizeRaf);
        }

        previewResizeRaf = window.requestAnimationFrame(() => {
            previewResizeRaf = 0;
            clampPreviewIntoViewport();

            if (state.previewMode === "fit") {
                applyPreviewFitMode();
            } else {
                updatePreviewInfoText();
                updatePreviewPanCursor();
            }
        });
    }

    function installPreviewResizeObserver() {
        if (!previewCard || typeof ResizeObserver !== "function") return;

        const ro = new ResizeObserver(() => {
            syncPreviewAfterCardResize();
        });

        ro.observe(previewCard);
    }

    function renderFolderGlyph() {
        const wrap = document.createElement("div");
        wrap.className = "folderGlyph";
        wrap.innerHTML = `
      <svg viewBox="0 0 64 64" width="72" height="72" aria-hidden="true">
        <path d="M8 18h16l5 6h27v22c0 4.4-3.6 8-8 8H16c-4.4 0-8-3.6-8-8V26c0-4.4 3.6-8 8-8z"
              fill="currentColor" opacity="0.18"></path>
        <path d="M8 20c0-4.4 3.6-8 8-8h13l5 6h14c4.4 0 8 3.6 8 8v4H8v-10z"
              fill="currentColor" opacity="0.34"></path>
        <rect x="8" y="22" width="48" height="30" rx="8" fill="none" stroke="currentColor" stroke-width="3"></rect>
      </svg>`;
        return wrap;
    }

    function buildStars(current, onPick) {
        const row = document.createDocumentFragment();
        for (let i = 1; i <= 5; i++) {
            const b = document.createElement("button");
            b.type = "button";
            b.className = `starBtn${i <= current ? " on" : ""}`;
            b.textContent = "★";
            b.title = `${i} star${i === 1 ? "" : "s"}`;
            b.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                onPick(i);
            });
            row.appendChild(b);
        }
        return row;
    }

    function updateMetaStars() {
        if (!metaStars) return;
        metaStars.innerHTML = "";
        metaStars.appendChild(buildStars(state.editingRating, (i) => {
            state.editingRating = i;
            updateMetaStars();
        }));
        const clearBtn = document.createElement("button");
        clearBtn.type = "button";
        clearBtn.className = "btn secondary";
        clearBtn.style.marginLeft = "8px";
        clearBtn.textContent = "Clear";
        clearBtn.addEventListener("click", () => {
            state.editingRating = 0;
            updateMetaStars();
        });
        metaStars.appendChild(clearBtn);
    }

    function openMetaModal() {
        if (!metaModal) return;
        placeMetaCentered();
        metaModal.classList.add("show");
        metaModal.setAttribute("aria-hidden", "false");
    }

    function closeMetaModal() {
        if (!metaModal) return;
        metaModal.classList.remove("show");
        metaModal.setAttribute("aria-hidden", "true");
        state.editingPath = "";
        suppressBrowserSaveUntil = Date.now() + 700;
    }

    async function openMetaFor(itemOrPath) {
        const rel = typeof itemOrPath === "string"
            ? itemOrPath
            : currentRelPathFor(itemOrPath);

        state.editingPath = rel;
        window.PQNAS_PHOTOGALLERY_EMBEDDED_META?.reset(rel);
        state.editingRating = 0;

        if (metaPath) metaPath.textContent = "/" + rel;
        if (metaTags) metaTags.value = "";
        if (metaNotes) metaNotes.value = "";
        if (metaInfo) metaInfo.textContent = "Loading…";
        if (metaStatus) metaStatus.textContent = "Loading…";
        const selectedImagesNow = selectedImageRelPaths();
        if (metaApplySelChk) {
            metaApplySelChk.checked =
                selectedImagesNow.length > 1 && selectedImagesNow.includes(rel);
        }
        updateMetaStars();
        refreshMetaApplySelectionUi();
        openMetaModal();

        window.dispatchEvent(new CustomEvent("photogallery:meta-open", {
            detail: { relPath: rel }
        }));

        try {
            const j = await galleryMetaGet(rel);
            const meta = j.meta || {};
            const { imageRating, keywords, description } = normalizeGalleryMeta(meta);

            state.editingRating = imageRating;
            if (metaTags) metaTags.value = keywords.join(", ");
            if (metaNotes) metaNotes.value = description;

            const sizeBytes =
                j.file && j.file.size_bytes != null
                    ? Number(j.file.size_bytes || 0)
                    : Number(meta.size_bytes || 0);

            const mtimeEpoch =
                j.file && j.file.mtime_epoch != null
                    ? Number(j.file.mtime_epoch || 0)
                    : Number(meta.mtime_epoch || 0);

            if (metaInfo) {
                metaInfo.textContent =
                    `${fmtSize(sizeBytes)} • ${fmtTime(mtimeEpoch) || "unknown time"}`;
            }

            if (metaStatus) metaStatus.textContent = "Ready.";
            updateMetaStars();
        } catch (e) {
            if (metaInfo) metaInfo.textContent = "Could not load metadata";
            if (metaStatus) metaStatus.textContent = `Error: ${String(e && e.message ? e.message : e)}`;
        }
    }

    async function saveMeta() {
        if (!state.editingPath || metaSaveInFlight) return;

        const rel = state.editingPath;
        const applyToSelection =
            !!(metaApplySelWrap && metaApplySelChk && metaApplySelChk.checked);

        let targets = applyToSelection ? selectedImageRelPaths() : [rel];

        if (!targets.includes(rel)) {
            targets = [rel, ...targets];
        }

        targets = Array.from(new Set(targets));

        const payload = {
            meta: {
                description: {
                    "x-default": String(metaNotes ? metaNotes.value : "").trim()
                },
                keywords: String(metaTags ? metaTags.value : "")
                    .split(",")
                    .map(s => s.trim())
                    .filter(Boolean),
                imageRating: Number(state.editingRating || 0)
            }
        };

        metaSaveInFlight = true;
        suppressBrowserSaveUntil = Date.now() + 1500;

        if (metaSaveBtn) {
            metaSaveBtn.disabled = true;
            metaSaveBtn.textContent = "Saving…";
        }
        if (metaStatus) {
            metaStatus.textContent =
                targets.length > 1
                    ? `Saving to ${targets.length} photos…`
                    : "Saving…";
        }

        let done = 0;
        const failed = [];

        try {
            for (const targetRel of targets) {
                try {
                    const j = await galleryMetaSet(targetRel, payload);
                    const meta = j.meta || {};
                    applyMetaToCaches(targetRel, meta);
                    done++;
                } catch (e) {
                    failed.push(`${targetRel}: ${String(e && e.message ? e.message : e)}`);
                }
            }

            renderGrid();
            window.dispatchEvent(new CustomEvent("photogallery:view-updated"));

            if (failed.length) {
                if (metaStatus) {
                    metaStatus.textContent = `Saved ${done}/${targets.length}. Failed: ${failed.length}`;
                }
                setBadge("warn", "partial");
                setStatus(`Metadata saved to ${done}/${targets.length} photo${targets.length === 1 ? "" : "s"}.`);
                console.warn("Photo Gallery saveMeta partial failures:", failed);
                return;
            }

            if (metaStatus) metaStatus.textContent = "Saved.";
            setBadge("ok", "ready");

            if (targets.length > 1) {
                setStatus(`Saved metadata to ${targets.length} photos.`);
            } else {
                setStatus(`Saved metadata: ${rel}`);
            }

            suppressBrowserSaveUntil = Date.now() + 1500;
            closeMetaModal();
        } catch (e) {
            if (metaStatus) {
                metaStatus.textContent = `Save failed: ${String(e && e.message ? e.message : e)}`;
            }
            setBadge("err", "error");
        } finally {
            metaSaveInFlight = false;
            if (metaSaveBtn) {
                metaSaveBtn.disabled = false;
                metaSaveBtn.textContent = "Save";
            }
        }
    }

    async function quickRate(item, rating) {
        const rel = currentRelPathFor(item);
        try {
            const j = await galleryMetaSet(rel, {
                meta: {
                    imageRating: Number(rating || 0)
                }
            });

            const meta = j.meta || {};
            const { imageRating } = normalizeGalleryMeta(meta);

            applyMetaToCaches(rel, meta);
            renderGrid();
            window.dispatchEvent(new CustomEvent("photogallery:view-updated"));
            setBadge("ok", "ready");
            setStatus(`Rated ${item.name}: ${imageRating}/5`);
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Rating failed: ${String(e && e.message ? e.message : e)}`);
        }
    }

    function rawJpegPairTooltip() {
        const exportAction = pgT(
            "photogallery.menu.export_metadata",
            null,
            "Export with metadata…"
        );

        return pgT(
            "photogallery.raw_jpeg_pair_tooltip",
            { action: exportAction },
            `RAW + JPEG pair. Download the RAW file by choosing “${exportAction}”.`
        );
    }

    function refreshRawJpegPairTooltips() {
        const tooltip = rawJpegPairTooltip();

        for (const badge of gridEl?.querySelectorAll(".pgPairBadge") || []) {
            badge.title = tooltip;
        }
    }

    window.addEventListener(
        "pqnas-language-changed",
        refreshRawJpegPairTooltips
    );

    function makeTile(item) {
        const tile = document.createElement("div");
        tile.className = "tile";
        tile.dataset.relPath = currentRelPathFor(item);
        tile.dataset.itemType = item.type;

        tile.tabIndex = -1;
        tile.setAttribute("role", "button");
        tile.setAttribute("aria-selected", "false");

        const thumbWrap = document.createElement("div");
        thumbWrap.className = "thumbWrap";

        if (item.type === "dir") {
            thumbWrap.appendChild(renderFolderGlyph());
        } else {
            const rel = currentRelPathFor(item);
            const capture = item && item._pg_capture;
            const rawOnly = isRawName(item.name || "") && !(capture && capture.pair_kind === "raw+jpeg");

            if (rawOnly) {
                thumbWrap.appendChild(renderRawGlyph());
            } else {
                const img = document.createElement("img");
                img.className = "thumb";
                img.loading = "lazy";
                img.decoding = "async";
                img.alt = item.name || "image";

                const reqThumbSize = Math.max(160, Number(state.thumbSize || 160) * 2);

                img.onerror = () => {
                    img.onerror = null;
                    img.classList.add("thumbError");
                    img.removeAttribute("src");
                    img.alt = "Thumbnail failed";
                };

                deferThumbLoad(
                    img,
                    galleryThumbUrl(rel, reqThumbSize, item.mtime_unix || 0)
                );

                thumbWrap.appendChild(img);
            }

            if (capture && capture.pair_kind === "raw+jpeg") {
                const pairBadge = document.createElement("div");
                pairBadge.className = "pgPairBadge";
                pairBadge.textContent = "R+J";
                pairBadge.title = rawJpegPairTooltip();
                thumbWrap.appendChild(pairBadge);
            }
        }

        const tools = document.createElement("div");
        tools.className = "tileTools";

        if (item.type === "file") {
            const metaBtn = document.createElement("button");
            metaBtn.type = "button";
            metaBtn.className = "miniBtn";
            metaBtn.title = "Edit metadata";
            metaBtn.textContent = "✎";
            metaBtn.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                openMetaFor(item);
            });
            tools.appendChild(metaBtn);
        }

        thumbWrap.appendChild(tools);

        const body = document.createElement("div");
        body.className = "tileBody";

        const name = document.createElement("div");
        name.className = "name";
        name.textContent = item.name || "(unnamed)";

        const meta = document.createElement("div");
        meta.className = "meta";

        const left = document.createElement("span");
        left.textContent = item.type === "dir" ? "dir" : fmtSize(item.size_bytes || 0);

        const right = document.createElement("span");
        right.textContent = fmtTime(item.mtime_unix || 0);

        meta.appendChild(left);
        meta.appendChild(right);

        body.appendChild(name);
        body.appendChild(meta);

        if (item.type === "file") {
            const stars = document.createElement("div");
            stars.className = "starRow";
            stars.appendChild(buildStars(Number(item.rating || 0) || 0, (i) => quickRate(item, i)));
            body.appendChild(stars);

            const tagLine = document.createElement("div");
            tagLine.className = "tagLine";

            const tagPreview =
                Array.isArray(item.keywords) && item.keywords.length
                    ? item.keywords.join(", ")
                    : (item.tags_text || "");

            const exifPreview = exifPreviewText(item);
            tagLine.textContent = tagPreview
                ? shorten(tagPreview, 60)
                : (exifPreview ? shorten(exifPreview, 60) : "No metadata");
            body.appendChild(tagLine);
        } else {
            const tagLine = document.createElement("div");
            tagLine.className = "tagLine";
            tagLine.textContent = "Open folder";
            body.appendChild(tagLine);
        }

        tile.appendChild(thumbWrap);
        tile.appendChild(body);
        tile.addEventListener("contextmenu", (e) => {
            e.preventDefault();
            e.stopPropagation();

            const rel = tile.dataset.relPath || "";
            if (!rel) return;

            setActiveTileRelPath(rel, { scroll: false, focus: false });

            if (selectedRelPaths.size > 1) {
                if (!selectedRelPaths.has(rel)) {
                    setSingleSelection(rel);
                    selectionAnchorRelPath = rel;
                }
            } else {
                ensureSelected(rel);
                selectionAnchorRelPath = rel;
            }

            if (selectedRelPaths.size > 1 && selectedRelPaths.has(rel)) {
                openSelectionContextMenu(e.clientX, e.clientY);
            } else if (item.type === "file") {
                openImageContextMenu(e.clientX, e.clientY, item);
            } else if (item.type === "dir") {
                openFolderContextMenu(e.clientX, e.clientY, item);
            }
        });

        tile.addEventListener("dblclick", () => {
            if (item.type === "dir") {
                setCurrentPath(currentRelPathFor(item), "folder-dblclick");
                clearSelection();
                load();
            } else {
                openPreviewFor(item);
            }
        });

        tile.addEventListener("click", (e) => {
            if (marqueeOn) return;

            const rel = tile.dataset.relPath || "";
            if (!rel) return;

            const additive = (e.ctrlKey || e.metaKey);

            if (e.shiftKey) {
                const anchor =
                    selectionAnchorRelPath ||
                    (selectedRelPaths.size ? Array.from(selectedRelPaths)[0] : rel);
                selectRange(anchor, rel, additive);
                return;
            }

            if (additive) {
                toggleSelection(rel);
                if (selectedRelPaths.has(rel)) selectionAnchorRelPath = rel;
            } else {
                setSingleSelection(rel);
                selectionAnchorRelPath = rel;
            }
        });

        return tile;
    }
    function makeBurstBlock(burst) {
        const wrap = document.createElement("div");
        wrap.className = burst.expanded ? "pgBurst pgBurstExpanded" : "pgBurst";
        wrap.dataset.burstKey = burst.key;

        const coverTile = makeTile(burst.cover);
        coverTile.classList.add("pgBurstCoverTile");

        const thumbWrap = coverTile.querySelector(".thumbWrap");
        if (thumbWrap) {
            const burstCount = Array.isArray(burst.items) ? burst.items.length : 0;

            const hasRawPair =
                Array.isArray(burst.captures) &&
                burst.captures.some((cap) => cap && cap.pair_kind === "raw+jpeg");

            // makeTile() may already have added a pair marker for the cover.
            // Remove it first so the burst cover never gets duplicate markers.
            thumbWrap
                .querySelectorAll(".pgPairBadge")
                .forEach((node) => node.remove());

            if (hasRawPair) {
                const pairBadge = document.createElement("div");
                pairBadge.className = "pgPairBadge";
                pairBadge.textContent = "R+J";
                pairBadge.title = rawJpegPairTooltip();
                thumbWrap.appendChild(pairBadge);
            }

            const burstBtn = document.createElement("button");
            burstBtn.type = "button";
            burstBtn.className = "pgBurstBadge";
            burstBtn.title = burst.expanded ? "Hide burst" : "Show burst";
            burstBtn.setAttribute(
                "aria-label",
                `${burst.expanded ? "Hide" : "Show"} burst ${burstCount}`
            );
            burstBtn.setAttribute(
                "aria-expanded",
                burst.expanded ? "true" : "false"
            );
            burstBtn.innerHTML = `
                <span>Burst ${burstCount}</span>
                <span class="pgBurstBadgeIcon" aria-hidden="true">
                    ${burst.expanded ? "−" : "+"}
                </span>
            `;

            burstBtn.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();

                window.PQNAS_PHOTOGALLERY
                    ?.bursts
                    ?.toggleExpanded(burst.key);

                renderGrid();

                window.dispatchEvent(
                    new CustomEvent("photogallery:view-updated")
                );
            });

            thumbWrap.appendChild(burstBtn);
        }

        wrap.appendChild(coverTile);

        if (burst.expanded) {
            const itemsWrap = document.createElement("div");
            itemsWrap.className = "pgBurstItems";

            burst.items.forEach((it, idx) => {
                if (idx === burst.coverIdx) return;
                itemsWrap.appendChild(makeTile(it));
            });

            wrap.appendChild(itemsWrap);
        }

        return wrap;
    }
    function hasUsableGps(item) {
        if (!item || item.type !== "file" || !item.has_gps) return false;

        const rawLat = item.gps_latitude;
        const rawLon = item.gps_longitude;

        if (
            rawLat == null ||
            rawLon == null ||
            rawLat === "" ||
            rawLon === ""
        ) {
            return false;
        }

        const lat = Number(rawLat);
        const lon = Number(rawLon);

        return (
            Number.isFinite(lat) &&
            Number.isFinite(lon) &&
            lat >= -90 &&
            lat <= 90 &&
            lon >= -180 &&
            lon <= 180
        );
    }

    function showItemOnMap(item) {
        if (!hasUsableGps(item)) return;

        state.mapFocusRelPath = currentRelPathFor(item);
        setViewMode("map");
    }

    function mapItems() {
        return filteredItems().filter(hasUsableGps);
    }

    function applyViewModeUi() {
        const mapOn = state.viewMode === "map";
        const albumsOn = state.viewMode === "albums";
        const gridOn = !mapOn && !albumsOn;

        gridWrap?.classList.toggle("hidden", !gridOn);
        mapWrap?.classList.toggle("hidden", !mapOn);
        albumsWrap?.classList.toggle("hidden", !albumsOn);

        if (albumsWrap) {
            albumsWrap.setAttribute("aria-hidden", albumsOn ? "false" : "true");
        }

        gridBtn?.classList.toggle("active", gridOn);
        mapBtn?.classList.toggle("active", mapOn);
        albumsBtn?.classList.toggle("active", albumsOn);

        // Keep the prominent top-bar indicator synchronized also when
        // the view changes programmatically, such as "Show on map".
        setTopModeButtonActive(state.viewMode);
    }

    function setViewMode(mode) {
        if (mode === "map") {
            state.viewMode = "map";
        } else if (mode === "albums") {
            state.viewMode = "albums";
        } else {
            state.viewMode = "grid";
        }

        if (state.viewMode !== "map") {
            state.mapFocusRelPath = "";
            window.PQNAS_PHOTOGALLERY?.map?.destroyMap?.();
        }

        renderGrid();
        updateViewStatus();

        if (state.viewMode === "map") {
            window.setTimeout(() => {
                try {
                    window.PQNAS_PHOTOGALLERY?.map?.runtime?.map?.invalidateSize?.();
                } catch (_) {}
            }, 0);
        }
    }

    function renderMap() {
        if (!mapCanvas) return;

        if (isSearchMode() && state.searchLoading && !state.searchLoaded) {
            mapCanvas.replaceChildren();

            const loading = document.createElement("div");
            loading.className = "emptyState";
            loading.innerHTML = `
            <div class="h">Searching subfolders…</div>
            <div class="p">Scanning the current folder and all deeper folders for photos with GPS coordinates.</div>
        `;
            mapCanvas.appendChild(loading);
            refreshFooterStats();
            return;
        }

        const items = mapItems();

        window.PQNAS_PHOTOGALLERY?.map?.render(mapCanvas, items, {
            currentRelPathFor,
            fmtTime,
            openPreviewFor,
            refreshFooterStats,
            galleryThumbUrl,
            focusRelPath: state.mapFocusRelPath,
            onFocusApplied(relPath) {
                if (state.mapFocusRelPath === relPath) {
                    state.mapFocusRelPath = "";
                }
            }
        });
    }

    function escapeHtml(s) {
        return String(s || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function destroyLeafletMap() {
        if (mapRuntime.map) {
            try { mapRuntime.map.remove(); } catch (_) {}
        }
        mapRuntime.map = null;
        mapRuntime.markersLayer = null;
        mapRuntime.tileLayer = null;
    }

    function ensureLeafletLoaded() {
        if (window.L) return Promise.resolve(window.L);
        if (mapRuntime.leafletPromise) return mapRuntime.leafletPromise;

        mapRuntime.leafletPromise = new Promise((resolve, reject) => {
            const cssHref = "./leaflet.css";
            const jsSrc = "./leaflet.js";

            const hasCss = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
                .some((el) => (el.getAttribute("href") || "") === cssHref);

            if (!hasCss) {
                const link = document.createElement("link");
                link.rel = "stylesheet";
                link.href = cssHref;
                document.head.appendChild(link);
            }

            const existingScript = Array.from(document.querySelectorAll("script"))
                .find((el) => (el.getAttribute("src") || "") === jsSrc);

            if (window.L) {
                resolve(window.L);
                return;
            }

            if (existingScript) {
                existingScript.addEventListener("load", () => resolve(window.L), { once: true });
                existingScript.addEventListener("error", () => reject(new Error("Failed to load Leaflet script")), { once: true });
                return;
            }

            const script = document.createElement("script");
            script.src = jsSrc;
            script.async = true;
            script.onload = () => {
                if (window.L) resolve(window.L);
                else reject(new Error("Leaflet loaded but window.L is missing"));
            };
            script.onerror = () => reject(new Error("Failed to load Leaflet script"));
            document.head.appendChild(script);
        });

        return mapRuntime.leafletPromise;
    }

    function buildMapSideList(items, markerByPath) {
        const list = document.createElement("div");
        list.className = "mapPhotoList";

        for (const item of items) {
            const rel = currentRelPathFor(item);

            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "mapPhotoBtn";

            const main = document.createElement("div");
            main.className = "mapPhotoMain";

            const name = document.createElement("div");
            name.className = "mapPhotoName";
            name.textContent = item.name || "(unnamed)";

            const path = document.createElement("div");
            path.className = "mapPhotoPath";
            path.textContent = "/" + rel;

            const coord = document.createElement("div");
            coord.className = "mapPhotoCoord";
            coord.textContent = `${Number(item.gps_latitude).toFixed(6)}, ${Number(item.gps_longitude).toFixed(6)}`;

            const time = document.createElement("div");
            time.className = "mapPhotoTime";
            time.textContent = fmtTime(item.capture_time_unix || 0) || "no capture time";

            main.appendChild(name);
            main.appendChild(path);
            main.appendChild(coord);
            main.appendChild(time);

            btn.appendChild(main);

            btn.addEventListener("click", () => {
                const marker = markerByPath.get(rel);
                if (marker && mapRuntime.map) {
                    mapRuntime.map.setView(marker.getLatLng(), Math.max(mapRuntime.map.getZoom(), 13), { animate: true });
                    marker.openPopup();
                }
                openPreviewFor(item);
            });

            list.appendChild(btn);
        }

        return list;
    }

    function renderGrid() {
        applyViewModeUi();

        if (state.viewMode === "map") {
            renderMap();
            return;
        }
        if (state.viewMode === "albums") {
            if (!albumsWrap) return;

            if (window.PQNAS_PHOTOGALLERY?.albumsView) {
                setBadge("warn", "loading…");
                setStatus("Loading albums…");

                Promise.resolve(
                    window.PQNAS_PHOTOGALLERY.albumsView.render(albumsWrap, {
                        galleryThumbUrl,
                        openPreviewByRelPath,
                        setBadge,
                        setStatus
                    })
                )
                    .then(() => {
                        if (state.viewMode === "albums") {
                            setBadge("ok", "ready");
                            setStatus("Albums ready.");
                            refreshFooterStats();
                        }
                    })
                    .catch((e) => {
                        const msg = String(e && e.message ? e.message : e);
                        albumsWrap.innerHTML = `
                    <div class="emptyState">
                        <div class="h">Albums failed to load</div>
                        <div class="p">${msg}</div>
                    </div>
                `;
                        setBadge("err", "error");
                        setStatus(`Albums failed: ${msg}`);
                    });

                return;
            }

            albumsWrap.innerHTML = `
        <div class="emptyState">
            <div class="h">Loading albums…</div>
            <div class="p">Loading albums_view.js.</div>
        </div>
    `;

            ensureAlbumsViewLoaded()
                .then(() => {
                    if (state.viewMode === "albums") renderGrid();
                })
                .catch((e) => {
                    const msg = String(e && e.message ? e.message : e);
                    albumsWrap.innerHTML = `
                <div class="emptyState">
                    <div class="h">Albums module failed to load</div>
                    <div class="p">${msg}</div>
                </div>
            `;
                    setBadge("err", "error");
                    setStatus(`Albums module failed to load: ${msg}`);
                });

            return;
        }
        renderGridBody();
    }
    function renderGridBody() {
        if (!gridEl) return;

        clearObservedThumbs();
        gridEl.replaceChildren();

        if (isSearchMode() && state.searchLoading && !state.searchLoaded) {
            state.activeTilePath = "";
            const loading = document.createElement("div");
            loading.className = "emptyState";
            loading.innerHTML = `
            <div class="h">Searching subfolders…</div>
            <div class="p">Scanning the current folder and all deeper folders for matching photos.</div>
        `;
            gridEl.appendChild(loading);
            refreshFooterStats();
            return;
        }

        const items = filteredItems();

        if (!items.length) {
            state.activeTilePath = "";

            const empty = document.createElement("div");
            empty.className = "emptyState";

            if (isSearchMode()) {
                empty.innerHTML = `
        <div class="h">No matching photos</div>
        <div class="p">No photos matched the current search or rating filter in this folder or its subfolders.</div>
    `;
            } else {
                empty.innerHTML = `
        <div class="h">Nothing to show</div>
        <div class="p">This folder has no subfolders or supported images that match the current filter.</div>
    `;
            }

            gridEl.appendChild(empty);
            refreshFooterStats();
            return;
        }

        if (isSearchMode()) {
            const groups = new Map();

            for (const item of items) {
                const key = groupPathForItem(item);
                if (!groups.has(key)) groups.set(key, []);
                groups.get(key).push(item);
            }

            let first = true;
            for (const [folderPath, groupItems] of groups) {
                gridEl.appendChild(makeSearchGroupHeader(folderPath, groupItems.length, first));
                const displayGroupItems =
                    window.PQNAS_PHOTOGALLERY?.bursts?.buildDisplayItems
                        ? window.PQNAS_PHOTOGALLERY.bursts.buildDisplayItems(groupItems)
                        : groupItems.map((item) => ({ kind: "item", item }));

                for (const entry of displayGroupItems) {
                    if (entry.kind === "burst") gridEl.appendChild(makeBurstBlock(entry.burst));
                    else gridEl.appendChild(makeTile(entry.item));
                }
                first = false;
            }
        } else {
            const entries = displayItems();
            for (const entry of entries) {
                if (entry.kind === "burst") gridEl.appendChild(makeBurstBlock(entry.burst));
                else gridEl.appendChild(makeTile(entry.item));
            }
        }

        applySelectionToDom();
        ensureActiveTile();
        refreshFooterStats();
    }

    async function load(forceSearch = false) {
        closeContextMenu();
        setBadge("warn", "loading…");
        setStatus("Loading gallery…");

        try {
            const j = await fetchGalleryList(state.curPath, { force: forceSearch });
            state.items = filterInternalPqnasGalleryItems(Array.isArray(j.items) ? j.items : []);
            if (state.treeStats.basePath !== state.curPath) {
                resetTreeStats();
            }
            refreshFooterStats();

            if (ENABLE_AUTO_TREE_STATS) {
                ensureTreeStats(forceSearch)
                    .then(() => refreshFooterStats())
                    .catch(() => refreshFooterStats());
            } else {
                refreshFooterStats();
            }
            renderBreadcrumb();

            if (forceSearch || state.searchBasePath !== state.curPath) {
                invalidateSearchCache();
            }

            await refreshVisibleView(forceSearch);
        } catch (e) {
            const msg = String(e && e.message ? e.message : e);
            if (msg === "__stale_search__") return;

            renderBreadcrumb();
            if (gridEl) {
                gridEl.innerHTML = `
                <div class="emptyState">
                    <div class="h">Load failed</div>
                    <div class="p">${msg}</div>
                </div>
            `;
            }


            if (msg.includes("not_found") || msg.includes("directory not found")) {
                const cur = normalizeRelPath(state.curPath);
                const parent = parentPath(cur);

                if (cur && parent !== cur) {
                    console.warn("[photogallery] path not found, falling back to parent", { cur, parent });
                    setCurrentPath(parent, "load-fallback-parent");
                    try {
                        await load(forceSearch);
                        return;
                    } catch (_) {}
                }
            }
            setBadge("err", "error");
            setStatus(`Load failed: ${msg}`);
        }
    }

    refreshBtn?.addEventListener("click", () => load(true));

    upBtn?.addEventListener("click", () => {
        setCurrentPath(parentPath(state.curPath), "up-button");
        clearSelection();
        load();
    });
    gridBtn?.addEventListener("click", () => {
        window.PQNAS_PHOTOGALLERY?.albumsView?.resetToList?.();
        setViewMode("grid");
    });

    mapBtn?.addEventListener("click", () => {
        window.PQNAS_PHOTOGALLERY?.albumsView?.resetToList?.();
        state.mapFocusRelPath = "";
        setViewMode("map");
    });

    albumsBtn?.addEventListener("click", async () => {
        try {
            setBadge("warn", "loading…");
            setStatus("Loading albums module…");

            await ensureAlbumsViewLoaded();

            window.PQNAS_PHOTOGALLERY?.albumsView?.resetToList?.();

            setViewMode("albums");
        } catch (e) {
            setBadge("err", "error");
            setStatus(`Albums module failed to load: ${String(e && e.message ? e.message : e)}`);
        }
    });
    filterInput?.addEventListener("input", () => {
        state.filter = String(filterInput.value || "");

        window.clearTimeout(filterTimer);

        if (isSearchMode() && (!state.searchLoaded || state.searchBasePath !== state.curPath)) {
            state.searchLoading = true;
            renderGrid();
            setBadge("warn", "search…");
            setStatus("Searching subfolders…");

            filterTimer = window.setTimeout(() => {
                refreshVisibleView(false);
            }, 180);
            return;
        }

        refreshVisibleView(false);
    });

    ratingFilter?.addEventListener("change", () => {
        state.ratingFilter = Number(ratingFilter.value || "-1");
        saveRatingFilterPref();
        refreshVisibleView(false);
    });

    thumbSizeSelect?.addEventListener("change", () => {
        state.thumbSize = Number(thumbSizeSelect.value || "160");
        applyThumbSizeUi();
        saveThumbSizePref();
        renderGrid();
        window.dispatchEvent(new CustomEvent("photogallery:view-updated"));

        const count = filteredItems().length;
        const rf = Number(state.ratingFilter);
        const ratingTxt =
            rf < 0 ? "" :
                (rf === 0 ? " • unrated only" : ` • ${rf}★ only`);
        const textTxt =
            state.filter ? ` • filter: ${state.filter}` : "";

        setStatus(`Items: ${count}${ratingTxt}${textTxt} • thumbs: ${state.thumbSize}px`);
    });

    metaClose?.addEventListener("click", closeMetaModal);
    metaModal?.addEventListener("click", (e) => {
        if (e.target === metaModal) closeMetaModal();
    });
    metaSaveBtn?.addEventListener("click", saveMeta);
    metaApplySelChk?.addEventListener("change", refreshMetaApplySelectionUi);
    previewClose?.addEventListener("click", closePreviewModal);
    previewModal?.addEventListener("click", (e) => {
        if (dragState.moved) {
            dragState.moved = false;
            return;
        }
        if (e.target === previewModal) closePreviewModal();
    });

    previewFitBtn?.addEventListener("click", applyPreviewFitMode);
    previewActualBtn?.addEventListener("click", applyPreviewActualMode);
    previewMetaBtn?.addEventListener("click", () => {
        const rel = state.previewPath;
        if (rel) openMetaFor(rel);
    });

    previewFullscreenBtn?.addEventListener("click", async () => {
        await togglePreviewFullscreen();
    });

    previewPrevBtn?.addEventListener("click", () => {
        const { idx } = currentPreviewIndex();
        if (idx >= 0) openPreviewByIndex(idx - 1);
    });

    previewNextBtn?.addEventListener("click", () => {
        const { idx } = currentPreviewIndex();
        if (idx >= 0) openPreviewByIndex(idx + 1);
    });

    previewBody?.addEventListener("wheel", (e) => {
        if (!previewModal || !previewModal.classList.contains("show")) return;
        if (!previewImg || !previewImg.naturalWidth || !previewImg.naturalHeight) return;

        e.preventDefault();
        e.stopPropagation();

        const baseZoom = currentPreviewZoom();
        const factor = Math.exp(-e.deltaY * 0.0015);

        applyPreviewZoom(baseZoom * factor, {
            clientX: e.clientX,
            clientY: e.clientY,
            snapToFit: true
        });
    }, { passive: false });

    previewImg?.addEventListener("dblclick", async (e) => {
        e.preventDefault();
        e.stopPropagation();

        if (isPreviewFullscreen()) {
            await exitPreviewFullscreen();
        } else {
            await enterPreviewFullscreen();
        }
    });

    previewBody?.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        if (!previewModal || !previewModal.classList.contains("show")) return;
        if (!isPreviewPannable()) return;

        previewPanState.active = true;
        previewPanState.startX = e.clientX;
        previewPanState.startY = e.clientY;
        previewPanState.scrollLeft = previewBody.scrollLeft;
        previewPanState.scrollTop = previewBody.scrollTop;
        previewPanState.moved = false;

        updatePreviewPanCursor();

        try { previewBody.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
    });

    previewBody?.addEventListener("pointermove", (e) => {
        if (!previewPanState.active || !previewBody) return;

        const dx = e.clientX - previewPanState.startX;
        const dy = e.clientY - previewPanState.startY;

        if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
            previewPanState.moved = true;
        }

        previewBody.scrollLeft = previewPanState.scrollLeft - dx;
        previewBody.scrollTop = previewPanState.scrollTop - dy;

        e.preventDefault();
    });

    function endPreviewPan() {
        if (!previewPanState.active) return;
        previewPanState.active = false;
        updatePreviewPanCursor();
    }

    previewBody?.addEventListener("pointerup", endPreviewPan);
    previewBody?.addEventListener("pointercancel", endPreviewPan);
    previewBody?.addEventListener("lostpointercapture", endPreviewPan);
    downloadSelBtn?.addEventListener("click", downloadSelectionZip);
    deleteSelBtn?.addEventListener("click", deleteSelection);
    clearSelBtn?.addEventListener("click", () => {
        clearSelection();
        setStatus(pgT("photogallery.selection_cleared", null, "Selection cleared."));
    });


    previewHead?.addEventListener("pointerdown", (e) => {
        if (!previewCard) return;
        if (e.target && e.target.closest && e.target.closest("button")) return;

        const rect = previewCard.getBoundingClientRect();
        dragState.active = true;
        dragState.startX = e.clientX;
        dragState.startY = e.clientY;
        dragState.cardLeft = rect.left;
        dragState.cardTop = rect.top;
        dragState.moved = false;

        previewCard.style.transform = "none";
        previewCard.style.left = `${rect.left}px`;
        previewCard.style.top = `${rect.top}px`;

        try { previewHead.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
    });

    previewHead?.addEventListener("pointermove", (e) => {
        if (!dragState.active || !previewCard) return;

        const dx = e.clientX - dragState.startX;
        const dy = e.clientY - dragState.startY;

        if (Math.abs(dx) > 2 || Math.abs(dy) > 2) dragState.moved = true;

        const rect = previewCard.getBoundingClientRect();
        const pad = 8;

        const nextLeft = clamp(
            dragState.cardLeft + dx,
            pad,
            Math.max(pad, window.innerWidth - rect.width - pad)
        );

        const nextTop = clamp(
            dragState.cardTop + dy,
            pad,
            Math.max(pad, window.innerHeight - rect.height - pad)
        );

        previewCard.style.left = `${nextLeft}px`;
        previewCard.style.top = `${nextTop}px`;
    });

    function endDrag() {
        dragState.active = false;
    }

    previewHead?.addEventListener("pointerup", endDrag);
    previewHead?.addEventListener("pointercancel", endDrag);

    metaHead?.addEventListener("pointerdown", (e) => {
        if (!metaCard) return;
        if (e.target && e.target.closest && e.target.closest("button")) return;

        const rect = metaCard.getBoundingClientRect();

        metaDragState.active = true;
        metaDragState.startX = e.clientX;
        metaDragState.startY = e.clientY;
        metaDragState.cardLeft = rect.left;
        metaDragState.cardTop = rect.top;

        metaCard.style.transform = "none";
        metaCard.style.left = `${rect.left}px`;
        metaCard.style.top = `${rect.top}px`;

        try { metaHead.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
    });

    metaHead?.addEventListener("pointermove", (e) => {
        if (!metaDragState.active || !metaCard) return;

        const dx = e.clientX - metaDragState.startX;
        const dy = e.clientY - metaDragState.startY;

        const rect = metaCard.getBoundingClientRect();
        const pad = 8;

        const nextLeft = clamp(
            metaDragState.cardLeft + dx,
            pad,
            Math.max(pad, window.innerWidth - rect.width - pad)
        );

        const nextTop = clamp(
            metaDragState.cardTop + dy,
            pad,
            Math.max(pad, window.innerHeight - rect.height - pad)
        );

        metaCard.style.left = `${nextLeft}px`;
        metaCard.style.top = `${nextTop}px`;
    });

    function endMetaDrag() {
        metaDragState.active = false;
    }

    metaHead?.addEventListener("pointerup", endMetaDrag);
    metaHead?.addEventListener("pointercancel", endMetaDrag);

    window.addEventListener("resize", () => {
        if (previewModal && previewModal.classList.contains("show")) {
            clampPreviewIntoViewport();
        }
        if (metaModal && metaModal.classList.contains("show")) {
            clampMetaIntoViewport();
        }
    });
    document.addEventListener("click", (e) => {
        if (!ctxMenu || !ctxMenu.classList.contains("show")) return;
        if (e.target === ctxMenu || ctxMenu.contains(e.target)) return;
        closeContextMenu();
    });
    document.addEventListener("keydown", (e) => {
        const previewOpen = !!(previewModal && previewModal.classList.contains("show"));
        const metaOpen = !!(metaModal && metaModal.classList.contains("show"));

        // Save hotkey handler lives elsewhere; don't interfere with typing.
        if (metaOpen) {
            if (e.key === "Escape") {
                e.preventDefault();
                closeMetaModal();
                return;
            }

            if (e.code === "Space" && !isTypingTarget(e.target)) {
                e.preventDefault();
                e.stopPropagation();
                closeMetaModal();
            }
            return;
        }

        if (previewOpen) {
            if (e.key === "Escape") {
                e.preventDefault();
                closePreviewModal();
                return;
            }

            if (e.key === "ArrowLeft") {
                e.preventDefault();
                const { idx } = currentPreviewIndex();
                if (idx >= 0) openPreviewByIndex(idx - 1);
                return;
            }

            if (e.key === "ArrowRight") {
                e.preventDefault();
                const { idx } = currentPreviewIndex();
                if (idx >= 0) openPreviewByIndex(idx + 1);
            }
            return;
        }

        if (isTypingTarget(e.target)) return;

        const tiles = getRenderedTiles();
        if (!tiles.length) return;

        if (e.key === "Escape") {
            closeContextMenu();
            return;
        }

        if (e.code === "Space") {
            e.preventDefault();
            e.stopPropagation();
            openSelectedTileMetadata();
            return;
        }

        switch (e.key) {
            case "ArrowLeft":
                e.preventDefault();
                moveLinear(-1);
                return;

            case "ArrowRight":
                e.preventDefault();
                moveLinear(1);
                return;

            case "ArrowUp":
                e.preventDefault();
                moveVertical(-1);
                return;

            case "ArrowDown":
                e.preventDefault();
                moveVertical(1);
                return;

            case "PageUp":
                e.preventDefault();
                moveByPage(-1);
                return;

            case "PageDown":
                e.preventDefault();
                moveByPage(1);
                return;

            case "Home":
                e.preventDefault();
                setSingleSelection(tiles[0].dataset.relPath || "", {
                    scroll: true,
                    focus: true
                });
                return;

            case "End":
                e.preventDefault();
                setSingleSelection(tiles[tiles.length - 1].dataset.relPath || "", {
                    scroll: true,
                    focus: true
                });
                return;

            case "Enter":
                e.preventDefault();
                activateSelectedTile();
                return;
        }
    });

    window.addEventListener("scroll", closeContextMenu, true);
    window.addEventListener("resize", () => {
        closeContextMenu();
        syncPreviewAfterCardResize();
    });

    installPreviewResizeObserver();

    window.PQNAS_PHOTOGALLERY.getFilteredImageItems = () => filteredImageItems().slice();
    window.PQNAS_PHOTOGALLERY.currentRelPathFor = currentRelPathFor;
    window.PQNAS_PHOTOGALLERY.openPreviewFor = openPreviewFor;
    window.PQNAS_PHOTOGALLERY.getPreviewPath = () => state.previewPath;
    window.PQNAS_PHOTOGALLERY.isPreviewOpen = () =>
        !!(previewModal && previewModal.classList.contains("show"));
    window.PQNAS_PHOTOGALLERY.setStatus = setStatus;
    window.PQNAS_PHOTOGALLERY.setBadge = setBadge;
    window.PQNAS_PHOTOGALLERY.getSelectedRelPaths = () => selectedRelPathsList();
    window.PQNAS_PHOTOGALLERY.clearSelection = clearSelection;

    window.PQNAS_PHOTOGALLERY.registerSearchFilterProvider = function (provider) {
        if (!provider || typeof provider.isActive !== "function" || typeof provider.matches !== "function") {
            return () => {};
        }

        externalSearchFilters.push(provider);

        return () => {
            const idx = externalSearchFilters.indexOf(provider);
            if (idx >= 0) externalSearchFilters.splice(idx, 1);
        };
    };

    window.PQNAS_PHOTOGALLERY.refreshSearchFilters = function (forceSearch = false) {
        return refreshVisibleView(!!forceSearch);
    };

    window.PQNAS_PHOTOGALLERY.getCurrentPath = function () {
        return state && typeof state.curPath === "string" ? state.curPath : "";
    };

    window.PQNAS_PHOTOGALLERY.getFilterState = function () {
        return {
            text: filterInput ? String(filterInput.value || "") : "",
            rating: ratingFilter ? String(ratingFilter.value || "-1") : "-1",
            thumbSize: thumbSizeSelect ? String(thumbSizeSelect.value || "160") : "160"
        };
    };

    window.PQNAS_PHOTOGALLERY.reload = async function (forceSearch = false) {
        if (typeof load === "function") {
            return await load(!!forceSearch);
        }
    };

    window.PQNAS_PHOTOGALLERY.api = window.PQNAS_PHOTOGALLERY.api || {};
    window.PQNAS_PHOTOGALLERY.api.statsUrl = function () {
        return "/api/v4/photogallery/stats";
    };

    async function getAppVersion() {
        const m = location.pathname.match(/^\/apps\/([^/]+)\/([^/]+)\//);
        if (m && m[2]) return decodeURIComponent(m[2]);

        for (const url of ["../manifest.json", "./manifest.json"]) {
            try {
                const r = await fetch(url, {
                    cache: "no-store",
                    headers: { "Accept": "application/json" }
                });
                if (!r.ok) continue;
                const j = await r.json();
                const ver = j && typeof j.version === "string" ? j.version.trim() : "";
                if (ver) return ver;
            } catch (_) {}
        }

        return "";
    }

    function setPhotoGalleryTitle(version) {
        if (!titleLine) return;

        titleLine.replaceChildren();

        const name = document.createElement("span");
        name.textContent = "Photo Gallery";
        titleLine.appendChild(name);

        if (!version) return;

        const versionEl = document.createElement("span");
        versionEl.id = "appVersion";
        versionEl.className = "appVersion";
        versionEl.textContent = `v${version}`;
        versionEl.title = `Photo Gallery ${version}`;
        titleLine.appendChild(versionEl);
    }

    async function initAppVersion() {
        const ver = await getAppVersion();
        setPhotoGalleryTitle(ver);
    }

    initAppVersion();
    loadRatingFilterPref();
    loadThumbSizePref();
    wireTopModeButtonActive();
    renderBreadcrumb();
    load();
})();